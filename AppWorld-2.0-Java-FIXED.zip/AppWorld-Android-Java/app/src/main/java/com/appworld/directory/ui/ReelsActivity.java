package com.appworld.directory.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.appworld.directory.databinding.ActivitySocialHubBinding;

/** AppWorld 2.0 Reels entry point. Social feed becomes live after Supabase Auth/storage setup. */
public class ReelsActivity extends AppCompatActivity {
    private ActivitySocialHubBinding binding;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        binding = ActivitySocialHubBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.textSocialTitle.setText("AppWorld Reels");
        binding.textSocialSubtitle.setText("Discover short videos from the AppWorld community.");
        binding.textSocialEmpty.setText("Your Reels feed is ready for the community.\n\nSign-in, secure media upload and the live feed are enabled after the AppWorld 2.0 Supabase setup is completed.");
        binding.btnSocialAction.setText("Back to AppWorld");
        binding.btnSocialAction.setOnClickListener(v -> finish());
        binding.btnSocialBack.setOnClickListener(v -> finish());
    }
}
