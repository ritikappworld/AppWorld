-- AppWorld 2.0 social foundation (Supabase SQL Editor)
-- Run in the existing project. Uses Supabase Auth; NEVER put service_role keys in Android.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default '',
  avatar_url text,
  bio text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  constraint user_follows_no_self check (follower_id <> following_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  title text,
  is_group boolean not null default false,
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text,
  media_url text,
  created_at timestamptz not null default now(),
  constraint messages_body_or_media check (nullif(trim(coalesce(body,'')), '') is not null or media_url is not null)
);

create table if not exists public.reels (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_url text not null,
  caption text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists public.reel_likes (
  reel_id uuid not null references public.reels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (reel_id, user_id)
);
create table if not exists public.reel_comments (
  id uuid primary key default gen_random_uuid(),
  reel_id uuid not null references public.reels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (length(trim(body)) > 0),
  created_at timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at desc);
create index if not exists reels_created_idx on public.reels(created_at desc);
create index if not exists follows_following_idx on public.user_follows(following_id);

-- Automatically create a profile for every newly registered Auth user.
create or replace function public.handle_new_appworld_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, username, display_name)
  values (new.id,
          null,
          coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_appworld on auth.users;
create trigger on_auth_user_created_appworld after insert on auth.users
for each row execute procedure public.handle_new_appworld_user();

alter table public.profiles enable row level security;
alter table public.user_follows enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.reels enable row level security;
alter table public.reel_likes enable row level security;
alter table public.reel_comments enable row level security;

-- SECURITY DEFINER helpers avoid recursive RLS checks between membership and conversation rows.
create or replace function public.appworld_is_conversation_member(p_conversation_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversation_members m
                 where m.conversation_id = p_conversation_id and m.user_id = auth.uid());
$$;
create or replace function public.appworld_is_conversation_creator(p_conversation_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversations c
                 where c.id = p_conversation_id and c.created_by = auth.uid());
$$;

drop policy if exists "Profiles are readable by signed-in users" on public.profiles;
create policy "Profiles are readable by signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
drop policy if exists "Users insert own profile" on public.profiles;
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (id = auth.uid());

drop policy if exists "Follow rows readable by signed-in users" on public.user_follows;
create policy "Follow rows readable by signed-in users" on public.user_follows for select to authenticated using (true);
drop policy if exists "Follow own account" on public.user_follows;
create policy "Follow own account" on public.user_follows for insert to authenticated with check (follower_id = auth.uid() and following_id <> auth.uid());
drop policy if exists "Unfollow own account" on public.user_follows;
create policy "Unfollow own account" on public.user_follows for delete to authenticated using (follower_id = auth.uid());

drop policy if exists "Members read their conversations" on public.conversations;
create policy "Members read their conversations" on public.conversations for select to authenticated using (public.appworld_is_conversation_member(id));
drop policy if exists "Signed-in users create conversations" on public.conversations;
create policy "Signed-in users create conversations" on public.conversations for insert to authenticated with check (created_by = auth.uid());
drop policy if exists "Members see conversation membership" on public.conversation_members;
create policy "Members see conversation membership" on public.conversation_members for select to authenticated using (public.appworld_is_conversation_member(conversation_id));
drop policy if exists "Conversation creator adds members" on public.conversation_members;
create policy "Conversation creator adds members" on public.conversation_members for insert to authenticated with check (public.appworld_is_conversation_creator(conversation_id));
drop policy if exists "Members read messages" on public.messages;
create policy "Members read messages" on public.messages for select to authenticated using (public.appworld_is_conversation_member(conversation_id));
drop policy if exists "Members send messages as themselves" on public.messages;
create policy "Members send messages as themselves" on public.messages for insert to authenticated with check (sender_id = auth.uid() and public.appworld_is_conversation_member(conversation_id));

drop policy if exists "Signed-in users read reels" on public.reels;
create policy "Signed-in users read reels" on public.reels for select to authenticated using (true);
drop policy if exists "Users publish own reels" on public.reels;
create policy "Users publish own reels" on public.reels for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users delete own reels" on public.reels;
create policy "Users delete own reels" on public.reels for delete to authenticated using (user_id = auth.uid());
drop policy if exists "Signed-in users read reel likes" on public.reel_likes;
create policy "Signed-in users read reel likes" on public.reel_likes for select to authenticated using (true);
drop policy if exists "Users like as themselves" on public.reel_likes;
create policy "Users like as themselves" on public.reel_likes for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users remove own likes" on public.reel_likes;
create policy "Users remove own likes" on public.reel_likes for delete to authenticated using (user_id = auth.uid());
drop policy if exists "Signed-in users read reel comments" on public.reel_comments;
create policy "Signed-in users read reel comments" on public.reel_comments for select to authenticated using (true);
drop policy if exists "Users comment as themselves" on public.reel_comments;
create policy "Users comment as themselves" on public.reel_comments for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users delete own comments" on public.reel_comments;
create policy "Users delete own comments" on public.reel_comments for delete to authenticated using (user_id = auth.uid());

-- Private media bucket. Use paths prefixed by the authenticated user's UUID.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('appworld-social', 'appworld-social', false, 52428800,
        array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime'])
on conflict (id) do nothing;
drop policy if exists "Users upload their own AppWorld media" on storage.objects;
create policy "Users upload their own AppWorld media" on storage.objects for insert to authenticated
with check (bucket_id = 'appworld-social' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Signed-in users read AppWorld media" on storage.objects;
create policy "Signed-in users read AppWorld media" on storage.objects for select to authenticated
using (bucket_id = 'appworld-social');
drop policy if exists "Users delete their own AppWorld media" on storage.objects;
create policy "Users delete their own AppWorld media" on storage.objects for delete to authenticated
using (bucket_id = 'appworld-social' and (storage.foldername(name))[1] = auth.uid()::text);

-- Realtime publication additions are guarded so rerunning this script is safe.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.reels;
exception when duplicate_object then null; when undefined_object then null; end $$;
