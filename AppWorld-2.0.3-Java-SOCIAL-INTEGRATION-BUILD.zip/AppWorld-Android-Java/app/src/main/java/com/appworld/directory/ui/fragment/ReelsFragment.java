package com.appworld.directory.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.appworld.directory.databinding.ActivitySocialHubBinding;

/** Reels tab entry. Does not display fabricated feed content. */
public class ReelsFragment extends Fragment {
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        ActivitySocialHubBinding b=ActivitySocialHubBinding.inflate(inflater,container,false);
        b.textSocialTitle.setText("AppWorld Reels");
        b.textSocialSubtitle.setText("Discover short videos from the AppWorld community.");
        b.textSocialEmpty.setText("Your Reels feed is ready for the community.\n\nSign in and connect the AppWorld media feed to publish and watch real community videos. No sample or fake videos are shown.");
        b.btnSocialAction.setText("Open Reels");
        b.btnSocialAction.setOnClickListener(v->startActivity(new android.content.Intent(requireContext(),com.appworld.directory.ui.ReelsActivity.class)));
        b.btnSocialBack.setVisibility(View.GONE);
        b.textSocialEmpty.setOnClickListener(v->startActivity(new android.content.Intent(requireContext(),com.appworld.directory.ui.ReelsActivity.class)));
        return b.getRoot();
    }
}
