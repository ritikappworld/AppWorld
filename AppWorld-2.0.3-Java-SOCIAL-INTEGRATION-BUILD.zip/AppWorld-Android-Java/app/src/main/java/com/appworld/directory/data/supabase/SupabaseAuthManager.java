package com.appworld.directory.data.supabase;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.IOException;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/** Minimal Supabase GoTrue email/password client. Never stores the user's password. */
public final class SupabaseAuthManager {
    public interface Result { void onComplete(boolean success, String message); }
    private static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    private static final String PREF = "appworld_auth_session";
    private static SupabaseAuthManager instance;
    private final Context app;
    private final SharedPreferences prefs;
    private final OkHttpClient client = new OkHttpClient();
    private final String baseUrl, anonKey;

    private SupabaseAuthManager(Context context, String url, String key) {
        app = context.getApplicationContext(); prefs = app.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        baseUrl = url == null ? "" : url.replaceAll("/+$", ""); anonKey = key == null ? "" : key;
    }
    public static synchronized void init(Context c, String url, String key) { if (instance == null) instance = new SupabaseAuthManager(c,url,key); }
    public static synchronized SupabaseAuthManager get() { if (instance == null) throw new IllegalStateException("Auth manager not initialized"); return instance; }
    public boolean isConfigured() { return !baseUrl.isEmpty() && !baseUrl.contains("your-project-ref") && !anonKey.isEmpty() && !anonKey.startsWith("YOUR_"); }
    public boolean isSignedIn() { return !getAccessToken().isEmpty(); }
    public String getAccessToken() { return prefs.getString("access_token", ""); }
    public String getEmail() { return prefs.getString("email", ""); }
    public String getUserId() { return prefs.getString("user_id", ""); }

    public void signIn(String email, String password, Result result) {
        JSONObject body = new JSONObject(); try { body.put("email",email); body.put("password",password); } catch(Exception e) { result.onComplete(false,"Could not prepare sign-in request."); return; }
        request("/auth/v1/token?grant_type=password", body, result, true);
    }
    public void signUp(String name, String email, String password, Result result) {
        JSONObject body = new JSONObject(); try { body.put("email",email); body.put("password",password); JSONObject data=new JSONObject(); data.put("display_name",name); body.put("data",data); } catch(Exception e) { result.onComplete(false,"Could not prepare sign-up request."); return; }
        request("/auth/v1/signup", body, result, true);
    }
    public void signOut(Result result) {
        if (!isConfigured()) { clear(); result.onComplete(true,"Signed out on this device."); return; }
        Request req = new Request.Builder().url(baseUrl+"/auth/v1/logout").header("apikey",anonKey).header("Authorization","Bearer "+getAccessToken()).post(RequestBody.create(JSON,"")).build();
        client.newCall(req).enqueue(new Callback(){ public void onFailure(Call c,IOException e){ clear(); result.onComplete(true,"Signed out on this device."); } public void onResponse(Call c,Response r){ try { clear(); result.onComplete(true,"Signed out."); } finally { r.close(); } } });
    }
    private void request(String path, JSONObject body, Result result, boolean saveSession) {
        if (!isConfigured()) { result.onComplete(false,"Supabase is not configured. Add SUPABASE_URL and SUPABASE_ANON_KEY in gradle.properties or GitHub Secrets."); return; }
        Request req=new Request.Builder().url(baseUrl+path).header("apikey",anonKey).header("Content-Type","application/json").post(RequestBody.create(JSON,body.toString())).build();
        client.newCall(req).enqueue(new Callback(){
            public void onFailure(Call c,IOException e){ result.onComplete(false,"Network error. Check your internet connection and Supabase URL."); }
            public void onResponse(Call c,Response r)throws IOException { String raw=r.body()!=null?r.body().string():""; boolean ok=r.isSuccessful(); String message=ok?"":errorMessage(raw); if(ok&&saveSession){ try { JSONObject data=new JSONObject(raw); String access=data.optString("access_token",""); if(!access.isEmpty()){ JSONObject user=data.optJSONObject("user"); prefs.edit().putString("access_token",access).putString("refresh_token",data.optString("refresh_token","")).putString("email",user==null?"":user.optString("email","")).putString("user_id",user==null?"":user.optString("id","")).apply(); message="Account connected successfully."; } else { JSONObject user=data.optJSONObject("user"); message=(user!=null?"Account created. Check your email to confirm, then sign in.":"Request completed."); } } catch(Exception e){ message="Account request completed, but the response could not be read."; ok=false; } } final boolean success=ok; final String msg=message; result.onComplete(success,msg); r.close(); }
        });
    }
    private String errorMessage(String raw) { try { JSONObject o=new JSONObject(raw); String m=o.optString("msg",o.optString("message",o.optString("error_description",o.optString("error","Request failed.")))); if(m.toLowerCase().contains("invalid login credentials")) return "Email or password is incorrect."; if(m.toLowerCase().contains("already registered")) return "This email is already registered. Please sign in."; return m; } catch(Exception e){ return "Supabase request failed. Check Auth settings and project configuration."; } }
    private void clear(){ prefs.edit().clear().apply(); }
}
