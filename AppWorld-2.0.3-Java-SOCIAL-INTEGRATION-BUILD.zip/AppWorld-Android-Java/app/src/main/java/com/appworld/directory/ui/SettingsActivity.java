package com.appworld.directory.ui;

import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import com.appworld.directory.data.local.UserDataManager;
import com.appworld.directory.databinding.ActivitySettingsBinding;

public class SettingsActivity extends AppCompatActivity {
    private ActivitySettingsBinding b;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivitySettingsBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        b.btnSettingsBack.setOnClickListener(v -> finish());
        b.btnSettingsNotifications.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Notifications").setMessage("Push notifications require AppWorld account sign-in and cloud notification integration. This control is not active yet.").setPositiveButton("OK", null).show());
        b.btnSettingsPrivacy.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Privacy & Security").setMessage("Favorites, search history, recently viewed items, profile name and collection names are stored locally on this device. Social account data requires the secure Supabase setup.").setPositiveButton("OK", null).show());
        b.btnSettingsAppearance.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Appearance").setItems(new String[]{"Light (current)", "Dark (coming soon)"}, (d, which) -> { if (which == 1) Toast.makeText(this, "Dark appearance is not included in this update.", Toast.LENGTH_SHORT).show(); }).show());
        b.btnSettingsLanguage.setOnClickListener(v -> Toast.makeText(this, "English is the current app language.", Toast.LENGTH_SHORT).show());
        b.btnSettingsClearHistory.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Clear search history?").setMessage("This only clears recent searches saved on this device.").setNegativeButton("Cancel", null).setPositiveButton("Clear", (d,w) -> { UserDataManager.get(this).clearSearchHistory(); Toast.makeText(this, "Search history cleared", Toast.LENGTH_SHORT).show(); }).show());
        b.btnSettingsAbout.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("About AppWorld").setMessage("AppWorld helps you discover apps, websites and AI tools, with favorites, search and community entry points.").setPositiveButton("OK", null).show());
    }
}
