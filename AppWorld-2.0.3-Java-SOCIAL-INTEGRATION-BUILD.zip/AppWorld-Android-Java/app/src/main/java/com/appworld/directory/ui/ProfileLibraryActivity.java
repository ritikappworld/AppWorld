package com.appworld.directory.ui;

import android.os.Bundle;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.appworld.directory.data.local.UserDataManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.ActivityProfileLibraryBinding;
import java.util.ArrayList;
import java.util.List;

public class ProfileLibraryActivity extends AppCompatActivity {
    private ActivityProfileLibraryBinding b;
    private UserDataManager user;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        b = ActivityProfileLibraryBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        user = UserDataManager.get(this);
        b.btnLibraryBack.setOnClickListener(v -> finish());
        b.btnLibraryAddCollection.setOnClickListener(v -> createCollection());
        refresh();
    }
    private void refresh() {
        List<String> recentNames = new ArrayList<>();
        List<String> ids = user.getRecentlyViewed();
        for (String id : ids) for (AppEntity app : SupabaseAppsRepository.getInstance().getCache()) if (app != null && id.equals(app.id)) { recentNames.add("• " + app.getSafeName() + "  ·  " + app.getSafeCategory()); break; }
        b.textLibraryRecent.setText(recentNames.isEmpty() ? "No recently viewed apps yet. Open an app to see it here." : android.text.TextUtils.join("\n", recentNames));
        List<String> collections = user.getCollections();
        b.textLibraryCollections.setText(collections.isEmpty() ? "Create collections to organize apps you like." : android.text.TextUtils.join("\n\n", collections));
    }
    private void createCollection() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("Collection name");
        new AlertDialog.Builder(this).setTitle("New Collection").setView(input).setNegativeButton("Cancel", null).setPositiveButton("Save", (d,w) -> {
            String name = input.getText().toString().trim();
            if (!name.isEmpty()) { user.addCollection(name); refresh(); }
        }).show();
    }
}
