package com.appworld.directory.data.supabase;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/** Supabase REST/Storage/Realtime gateway. Requires only the public anon/publishable key and a signed-in user JWT. */
public final class SupabaseSocialRepository {
    public interface Result { void onComplete(boolean ok, String bodyOrError); }
    public interface RealtimeListener { void onEvent(String payload); void onStatus(String status); }
    private static SupabaseSocialRepository instance;
    private final Context context;
    private final String baseUrl, anonKey;
    private final OkHttpClient http = new OkHttpClient();
    private WebSocket messagesSocket, reelsSocket;
    private ScheduledExecutorService heartbeatExecutor;
    private ScheduledFuture<?> heartbeatTask;
    private SupabaseSocialRepository(Context c, String url, String key) { context=c.getApplicationContext(); baseUrl=url==null?"":url.replaceAll("/+$",""); anonKey=key==null?"":key; }
    public static synchronized void init(Context c,String url,String key){ if(instance==null) instance=new SupabaseSocialRepository(c,url,key); }
    public static synchronized SupabaseSocialRepository get(){ if(instance==null) throw new IllegalStateException("Social repository not initialized"); return instance; }
    private String token(){ return SupabaseAuthManager.get().getAccessToken(); }
    public boolean isReady(){ return !baseUrl.isEmpty()&&!baseUrl.contains("your-project-ref")&&!anonKey.isEmpty()&&!anonKey.startsWith("YOUR_")&& !token().isEmpty(); }
    private void call(String method,String path,JSONObject json,byte[] bytes,String contentType,String prefer,Result cb){
        if(!isReady()){cb.onComplete(false,"Sign in and configure your Supabase project URL and public key in your private local build settings.");return;}
        RequestBody body=null; if(bytes!=null) body=RequestBody.create(MediaType.parse(contentType==null?"application/octet-stream":contentType),bytes); else if(json!=null) body=RequestBody.create(MediaType.parse("application/json; charset=utf-8"),json.toString()); else if(!"GET".equals(method)) body=RequestBody.create(null,new byte[0]);
        Request.Builder b=new Request.Builder().url(baseUrl+path).header("apikey",anonKey).header("Authorization","Bearer "+token()); if(prefer!=null&&!prefer.isEmpty()) b.header("Prefer",prefer); if(contentType!=null)b.header("Content-Type",contentType); b.method(method,body);
        http.newCall(b.build()).enqueue(new Callback(){public void onFailure(Call c,IOException e){cb.onComplete(false,"Network error: "+e.getMessage());} public void onResponse(Call c,Response r)throws IOException{String s=r.body()==null?"":r.body().string(); boolean ok=r.isSuccessful(); r.close(); cb.onComplete(ok,ok?s:parseError(s));}});
    }
    private String parseError(String s){try{JSONObject o=new JSONObject(s);return o.optString("message",o.optString("msg",o.optString("error",s)));}catch(Exception e){return s.isEmpty()?"Supabase request failed.":s;}}
    private static String enc(String s){try{return URLEncoder.encode(s,"UTF-8");}catch(Exception e){return s;}}
    private JSONObject obj(Object... kv){JSONObject o=new JSONObject();try{for(int i=0;i<kv.length;i+=2)o.put(String.valueOf(kv[i]),kv[i+1]);}catch(Exception ignored){}return o;}

    // Profile: read/update authenticated user's own record; avatar upload uses the same private bucket.
    public void getMyProfile(Result cb){call("GET","/rest/v1/profiles?id=eq."+enc(SupabaseAuthManager.get().getUserId())+"&select=*",null,null,null,null,cb);}
    public void updateMyProfile(String username,String displayName,String bio,String avatarUrl,Result cb){JSONObject p=new JSONObject();try{if(username!=null)p.put("username",username.trim().isEmpty()?JSONObject.NULL:username);if(displayName!=null)p.put("display_name",displayName);if(bio!=null)p.put("bio",bio);if(avatarUrl!=null)p.put("avatar_url",avatarUrl.trim().isEmpty()?JSONObject.NULL:avatarUrl);}catch(Exception ignored){}call("PATCH","/rest/v1/profiles?id=eq."+enc(SupabaseAuthManager.get().getUserId()),p,null,null,"return=representation",cb);}
    public void searchProfiles(String query,Result cb){call("GET","/rest/v1/profiles?select=id,username,display_name,avatar_url,bio&or=(username.ilike.*"+enc(query)+"*,display_name.ilike.*"+enc(query)+"*)&limit=30",null,null,null,null,cb);}
    public void follow(String userId,Result cb){call("POST","/rest/v1/user_follows",obj("follower_id",SupabaseAuthManager.get().getUserId(),"following_id",userId),null,null,"return=minimal",cb);}
    public void unfollow(String userId,Result cb){call("DELETE","/rest/v1/user_follows?follower_id=eq."+enc(SupabaseAuthManager.get().getUserId())+"&following_id=eq."+enc(userId),null,null,null,"return=minimal",cb);}
    public void getFollowers(String userId,Result cb){call("GET","/rest/v1/user_follows?following_id=eq."+enc(userId)+"&select=follower_id,created_at",null,null,null,null,cb);}
    public void getFollowing(String userId,Result cb){call("GET","/rest/v1/user_follows?follower_id=eq."+enc(userId)+"&select=following_id,created_at",null,null,null,null,cb);}
    public void toggleFollow(String targetUserId,Result cb){getFollowing(SupabaseAuthManager.get().getUserId(),(ok,data)->{if(!ok){cb.onComplete(false,data);return;}try{JSONArray a=new JSONArray(data);boolean following=false;for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optString("following_id").equals(targetUserId))following=true;if(following)unfollow(targetUserId,cb);else follow(targetUserId,cb);}catch(Exception e){cb.onComplete(false,"Could not check follow status.");}});}

    // Conversations and messages. Conversation creation is atomic through the SQL RPC shipped with this project.
    public void createConversation(String title,boolean group,JSONArray memberIds,Result cb){JSONObject p=obj("p_title",title==null?JSONObject.NULL:title,"p_is_group",group,"p_member_ids",memberIds==null?new JSONArray():memberIds);call("POST","/rest/v1/rpc/appworld_create_conversation",p,null,null,null,cb);}
    public void getConversations(Result cb){call("GET","/rest/v1/conversation_members?user_id=eq."+enc(SupabaseAuthManager.get().getUserId())+"&select=conversation_id,conversations(id,title,is_group,created_at)&order=joined_at.desc",null,null,null,null,cb);}
    public void getMessages(String conversationId,Result cb){call("GET","/rest/v1/messages?conversation_id=eq."+enc(conversationId)+"&select=*&order=created_at.asc&limit=200",null,null,null,null,cb);}
    public void sendMessage(String conversationId,String text,Result cb){call("POST","/rest/v1/messages",obj("conversation_id",conversationId,"sender_id",SupabaseAuthManager.get().getUserId(),"body",text),null,null,"return=representation",cb);}

    // Reels: upload binary to private Storage, then create metadata row. Return signed URL creation is separate.
    public void uploadMedia(Uri uri,String mimeType,Result cb){if(!isReady()){cb.onComplete(false,"Sign in and configure Supabase first.");return;}try{InputStream in=context.getContentResolver().openInputStream(uri);if(in==null){cb.onComplete(false,"Cannot open selected media.");return;}ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n,total=0;while((n=in.read(buf))!=-1){total+=n;if(total>50*1024*1024){in.close();cb.onComplete(false,"File exceeds the 50 MB upload limit.");return;}out.write(buf,0,n);}in.close();String ext=(mimeType!=null&&mimeType.contains("image"))?"jpg":"mp4";String path=SupabaseAuthManager.get().getUserId()+"/"+UUID.randomUUID()+"."+ext;call("POST","/storage/v1/object/appworld-social/"+path,null,out.toByteArray(),mimeType==null?"video/mp4":mimeType,"x-upsert:false",new Result(){public void onComplete(boolean ok,String response){cb.onComplete(ok,ok?path:response);}});}catch(Exception e){cb.onComplete(false,"Media upload failed: "+e.getMessage());}}
    public void publishReel(String storagePath,String caption,Result cb){call("POST","/rest/v1/reels",obj("user_id",SupabaseAuthManager.get().getUserId(),"video_url",storagePath,"caption",caption==null?"":caption),null,null,"return=representation",cb);}
    public void createSignedMediaUrl(String storagePath,Result cb){call("POST","/storage/v1/object/sign/appworld-social/"+storagePath,obj("expiresIn",3600),null,null,null,cb);}
    public void getReels(Result cb){call("GET","/rest/v1/reels?select=*&order=created_at.desc&limit=50",null,null,null,null,cb);}
    public void likeReel(String reelId,Result cb){call("POST","/rest/v1/reel_likes",obj("reel_id",reelId,"user_id",SupabaseAuthManager.get().getUserId()),null,null,"return=minimal",cb);}
    public void unlikeReel(String reelId,Result cb){call("DELETE","/rest/v1/reel_likes?reel_id=eq."+enc(reelId)+"&user_id=eq."+enc(SupabaseAuthManager.get().getUserId()),null,null,null,"return=minimal",cb);}
    public void toggleReelLike(String reelId,Result cb){getReelLikes(reelId,(ok,data)->{if(!ok){cb.onComplete(false,data);return;}try{JSONArray a=new JSONArray(data);boolean liked=false;for(int i=0;i<a.length();i++)if(a.getJSONObject(i).optString("user_id").equals(SupabaseAuthManager.get().getUserId()))liked=true;if(liked)unlikeReel(reelId,cb);else likeReel(reelId,cb);}catch(Exception e){cb.onComplete(false,"Could not check like status.");}});}
    public void getReelLikes(String reelId,Result cb){call("GET","/rest/v1/reel_likes?reel_id=eq."+enc(reelId)+"&select=user_id,created_at",null,null,null,null,cb);}
    public void addComment(String reelId,String body,Result cb){call("POST","/rest/v1/reel_comments",obj("reel_id",reelId,"user_id",SupabaseAuthManager.get().getUserId(),"body",body),null,null,"return=representation",cb);}
    public void getComments(String reelId,Result cb){call("GET","/rest/v1/reel_comments?reel_id=eq."+enc(reelId)+"&select=*&order=created_at.asc",null,null,null,null,cb);}

    public void getNotifications(Result cb){call("GET","/rest/v1/appworld_notifications?recipient_id=eq."+enc(SupabaseAuthManager.get().getUserId())+"&select=*&order=created_at.desc&limit=100",null,null,null,null,cb);}
    public void markNotificationsRead(Result cb){call("PATCH","/rest/v1/appworld_notifications?recipient_id=eq."+enc(SupabaseAuthManager.get().getUserId())+"&is_read=eq.false",obj("is_read",true),null,null,"return=minimal",cb);}
    // Supabase Realtime Phoenix protocol subscription for Postgres changes.
    public void subscribeMessages(String conversationId,RealtimeListener listener){subscribe("messages","conversation_id=eq."+conversationId,listener,true);}
    public void subscribeReels(RealtimeListener listener){subscribe("reels",null,listener,false);}
    private void subscribe(String table,String filter,RealtimeListener listener,boolean message){if(!isReady()){listener.onStatus("Sign in and configure Supabase before connecting Realtime.");return;}String wsUrl=baseUrl.replace("https://","wss://").replace("http://","ws://")+"/realtime/v1/websocket?apikey="+enc(anonKey)+"&vsn=1.0.0";JSONObject config=obj("broadcast",obj("ack",false,"self",false),"presence",obj("key",""));JSONArray changes=new JSONArray();JSONObject change=obj("event","*","schema","public","table",table);if(filter!=null)try{change.put("filter",filter);}catch(Exception ignored){}changes.put(change);try{config.put("postgres_changes",changes);}catch(Exception ignored){}JSONObject join=obj("config",config,"access_token",token());String topic="realtime:public:"+table;
        WebSocket ws=http.newWebSocket(new Request.Builder().url(wsUrl).build(),new WebSocketListener(){public void onOpen(WebSocket socket,Response response){socket.send(obj("topic",topic,"event","phx_join","payload",join,"ref","1").toString());listener.onStatus("Realtime connected");startHeartbeat(socket);}public void onMessage(WebSocket socket,String text){if(text.contains("\"event\":\"INSERT\"")||text.contains("\"event\":\"UPDATE\"")||text.contains("\"event\":\"DELETE\"")||text.contains("\"eventType\":\"INSERT\"")||text.contains("\"eventType\":\"UPDATE\"")||text.contains("\"eventType\":\"DELETE\""))listener.onEvent(text);}public void onClosed(WebSocket socket,int code,String reason){listener.onStatus("Realtime disconnected");}public void onFailure(WebSocket socket,Throwable t,Response r){listener.onStatus("Realtime disconnected: "+t.getMessage());}});if(message)messagesSocket=ws;else reelsSocket=ws;}
    private synchronized void startHeartbeat(final WebSocket socket){if(heartbeatExecutor==null)heartbeatExecutor=Executors.newSingleThreadScheduledExecutor();if(heartbeatTask!=null)heartbeatTask.cancel(true);heartbeatTask=heartbeatExecutor.scheduleAtFixedRate(()->socket.send(obj("topic","phoenix","event","heartbeat","payload",new JSONObject(),"ref",String.valueOf(System.currentTimeMillis())).toString()),25,25,TimeUnit.SECONDS);}
    public synchronized void stopRealtime(){if(heartbeatTask!=null){heartbeatTask.cancel(true);heartbeatTask=null;}if(heartbeatExecutor!=null){heartbeatExecutor.shutdownNow();heartbeatExecutor=null;}if(messagesSocket!=null){messagesSocket.close(1000,"screen closed");messagesSocket=null;}if(reelsSocket!=null){reelsSocket.close(1000,"screen closed");reelsSocket=null;}}
}
