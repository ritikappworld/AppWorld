package com.appworld.directory.ui;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.appworld.directory.data.supabase.SupabaseAuthManager;
import com.appworld.directory.databinding.ActivityAccountBinding;

public class AccountActivity extends AppCompatActivity {
    private ActivityAccountBinding b;
    private boolean signup=false;
    @Override protected void onCreate(Bundle state){ super.onCreate(state); b=ActivityAccountBinding.inflate(getLayoutInflater()); setContentView(b.getRoot());
        b.btnAccountBack.setOnClickListener(v->finish()); b.btnModeLogin.setOnClickListener(v->setMode(false)); b.btnModeSignup.setOnClickListener(v->setMode(true));
        b.btnAccountSubmit.setOnClickListener(v->submit()); b.btnAccountSignout.setOnClickListener(v->signOut()); refresh(); setMode(false);
    }
    private void setMode(boolean create){ signup=create; b.layoutDisplayName.setVisibility(create?View.VISIBLE:View.GONE); b.btnAccountSubmit.setText(create?"Create Account":"Sign In"); b.textAccountTitle.setText(create?"Create your AppWorld account":"Welcome back"); b.textAccountHint.setText(create?"Sign up with your email and password.":"Sign in to sync your AppWorld account."); b.btnModeLogin.setAlpha(create?.55f:1f); b.btnModeSignup.setAlpha(create?1f:.55f); }
    private void submit(){ String email=b.inputEmail.getText().toString().trim(), password=b.inputPassword.getText().toString(), name=b.inputDisplayName.getText().toString().trim(); if(email.isEmpty()||password.length()<6||(signup&&name.isEmpty())){ b.textAccountStatus.setText("Enter your name (for signup), a valid email and a password of at least 6 characters."); return; }
        b.btnAccountSubmit.setEnabled(false); b.textAccountStatus.setText("Connecting to Supabase…"); SupabaseAuthManager auth=SupabaseAuthManager.get(); SupabaseAuthManager.Result cb=(ok,msg)->runOnUiThread(()->{b.btnAccountSubmit.setEnabled(true);b.textAccountStatus.setText(msg);if(ok){refresh(); if(auth.isSignedIn()) Toast.makeText(this,"AppWorld account connected",Toast.LENGTH_SHORT).show();}});
        if(signup) auth.signUp(name,email,password,cb); else auth.signIn(email,password,cb);
    }
    private void signOut(){ SupabaseAuthManager.get().signOut((ok,msg)->runOnUiThread(()->{b.textAccountStatus.setText(msg);refresh();})); }
    private void refresh(){ boolean in=SupabaseAuthManager.get().isSignedIn(); b.textAccountSession.setText(in?"Signed in as\n"+SupabaseAuthManager.get().getEmail():"Not signed in"); b.btnAccountSignout.setVisibility(in?View.VISIBLE:View.GONE); }
}
