package com.appworld.directory.ui.fragment;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.appworld.directory.R;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.local.UserDataManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.data.supabase.SupabaseAuthManager;
import com.appworld.directory.data.supabase.SupabaseSocialRepository;
import com.appworld.directory.databinding.FragmentProfileBinding;
import com.appworld.directory.ui.MainActivity;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;

public class ProfileFragment extends Fragment {
    private FragmentProfileBinding b;
    private UserDataManager user;
    private static final int PICK_PHOTO = 731;
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        b = FragmentProfileBinding.inflate(inflater, container, false); user = UserDataManager.get(requireContext()); update();
        b.btnEditProfile.setOnClickListener(v -> editProfile());
        b.btnChangePhoto.setOnClickListener(v -> pickPhoto());
        b.btnMyProfile.setOnClickListener(v -> editProfile());
        b.btnDiscoverPeople.setOnClickListener(v -> discoverPeople());
        b.btnNotifications.setOnClickListener(v -> showNotifications());
        b.btnAccount.setOnClickListener(v -> startActivity(new Intent(requireContext(), com.appworld.directory.ui.AccountActivity.class)));
        b.btnMyFavorites.setOnClickListener(v -> { if (getActivity() instanceof MainActivity) ((MainActivity)getActivity()).selectFavorites(); });
        b.btnRecentlyViewed.setOnClickListener(v -> startActivity(new Intent(requireContext(), com.appworld.directory.ui.ProfileLibraryActivity.class)));
        b.btnCollections.setOnClickListener(v -> startActivity(new Intent(requireContext(), com.appworld.directory.ui.ProfileLibraryActivity.class)));
        b.btnSuggestApp.setOnClickListener(v -> suggestApp());
        b.btnRefreshProfile.setOnClickListener(v -> refreshApps());
        b.btnSettings.setOnClickListener(v -> startActivity(new Intent(requireContext(), com.appworld.directory.ui.SettingsActivity.class)));
        b.btnAbout.setOnClickListener(v -> showAbout());
        b.btnPrivacy.setOnClickListener(v -> new AlertDialog.Builder(requireContext()).setTitle("Privacy Policy").setMessage("AppWorld directory data is retrieved from Supabase. Profile name, photo reference, favorites, search history, recently viewed items and collection names are stored locally on this device. No sign-in is required.").setPositiveButton("OK", null).show());
        b.btnContact.setOnClickListener(v -> { Intent email=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"));email.putExtra(Intent.EXTRA_SUBJECT,"AppWorld Support");try{startActivity(Intent.createChooser(email,"Contact AppWorld"));}catch(ActivityNotFoundException e){Toast.makeText(requireContext(),"No email app found",Toast.LENGTH_SHORT).show();} });
        b.btnRate.setOnClickListener(v -> { Uri market=Uri.parse("market://details?id="+requireContext().getPackageName());try{startActivity(new Intent(Intent.ACTION_VIEW,market));}catch(ActivityNotFoundException e){startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://play.google.com/store/apps/details?id="+requireContext().getPackageName())));} });
        try { String version=requireContext().getPackageManager().getPackageInfo(requireContext().getPackageName(),0).versionName;b.textAppVersion.setText("App Version "+version); } catch(Exception ignored){b.textAppVersion.setText("App Version 1.3.0");}
        return b.getRoot();
    }
    @Override public void onResume(){ super.onResume(); if(user!=null) update(); }
    private void editProfile(){ if(!isAdded())return; EditText input=new EditText(requireContext());input.setSingleLine(true);input.setHint("Your name");input.setText(user.getName());input.setSelection(input.getText().length());new AlertDialog.Builder(requireContext()).setTitle("Edit Profile").setMessage("Your profile is saved on this device.").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String name=input.getText().toString().trim();if(name.isEmpty())name="AppWorld User";user.setName(name);update();syncProfile(null);}).show(); }
    private void pickPhoto(){ Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("image/*");try{startActivityForResult(i,PICK_PHOTO);}catch(Exception e){Toast.makeText(requireContext(),"Photo picker unavailable",Toast.LENGTH_SHORT).show();} }
    @Override public void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==PICK_PHOTO&&result==android.app.Activity.RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{requireContext().getContentResolver().takePersistableUriPermission(uri,data.getFlags()& (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION));}catch(Exception ignored){}user.setPhoto(uri.toString());update();if(SupabaseAuthManager.get().isSignedIn()){SupabaseSocialRepository.get().uploadMedia(uri,requireContext().getContentResolver().getType(uri),(ok,path)->{if(ok)syncProfile(path);else if(isAdded())requireActivity().runOnUiThread(()->Toast.makeText(requireContext(),path,Toast.LENGTH_LONG).show());});}}}

    private void syncProfile(String uploadedAvatarPath){
        if(!isAdded()||!SupabaseAuthManager.get().isSignedIn())return;
        String avatar=uploadedAvatarPath;
        SupabaseSocialRepository.get().updateMyProfile(null,user.getName(),"",avatar,(ok,msg)->{if(isAdded()&&!ok)requireActivity().runOnUiThread(()->Toast.makeText(requireContext(),"Profile saved locally; cloud sync: "+msg,Toast.LENGTH_LONG).show());});
    }


    private void showNotifications(){
        if(!SupabaseAuthManager.get().isSignedIn()){startActivity(new Intent(requireContext(),com.appworld.directory.ui.AccountActivity.class));return;}
        SupabaseSocialRepository.get().getNotifications((ok,data)->{if(!isAdded())return;requireActivity().runOnUiThread(()->{if(!ok){Toast.makeText(requireContext(),data,Toast.LENGTH_LONG).show();return;}try{org.json.JSONArray a=new org.json.JSONArray(data);StringBuilder s=new StringBuilder();for(int i=0;i<a.length();i++){org.json.JSONObject n=a.getJSONObject(i);s.append(n.optString("body")).append(" · ").append(n.optString("created_at")).append(n.optBoolean("is_read")?"":"  • NEW").append("\n\n");}new AlertDialog.Builder(requireContext()).setTitle("Notifications").setMessage(s.length()==0?"You are all caught up.":s.toString()).setPositiveButton("Mark all read",(d,w)->SupabaseSocialRepository.get().markNotificationsRead((x,m)->{})).setNegativeButton("Close",null).show();}catch(Exception e){Toast.makeText(requireContext(),"Could not read notifications",Toast.LENGTH_SHORT).show();}});});
    }
    private void discoverPeople(){
        if(!SupabaseAuthManager.get().isSignedIn()){startActivity(new Intent(requireContext(),com.appworld.directory.ui.AccountActivity.class));return;}
        EditText q=new EditText(requireContext());q.setHint("Search by name or username");
        new AlertDialog.Builder(requireContext()).setTitle("Discover People").setView(q).setNegativeButton("Cancel",null).setPositiveButton("Search",(d,w)->{String term=q.getText().toString().trim();if(term.isEmpty())return;SupabaseSocialRepository.get().searchProfiles(term,(ok,data)->{if(!isAdded())return;requireActivity().runOnUiThread(()->{if(!ok){Toast.makeText(requireContext(),data,Toast.LENGTH_LONG).show();return;}try{org.json.JSONArray a=new org.json.JSONArray(data);String[] labels=new String[a.length()];String[] ids=new String[a.length()];for(int i=0;i<a.length();i++){org.json.JSONObject p=a.getJSONObject(i);ids[i]=p.optString("id");labels[i]=p.optString("display_name",p.optString("username","AppWorld user"))+"  @"+p.optString("username");}new AlertDialog.Builder(requireContext()).setTitle("People found").setItems(labels,(dd,which)->SupabaseSocialRepository.get().toggleFollow(ids[which],(followed,msg)->{if(isAdded())requireActivity().runOnUiThread(()->Toast.makeText(requireContext(),followed?"Follow status updated":msg,Toast.LENGTH_LONG).show());})).show();}catch(Exception e){Toast.makeText(requireContext(),"Could not read profiles",Toast.LENGTH_SHORT).show();}});});}).show();
    }
    private void showRecentlyViewed(){List<AppEntity> found=new ArrayList<>();List<String> ids=user.getRecentlyViewed();for(String id:ids)for(AppEntity a:SupabaseAppsRepository.getInstance().getCache())if(a!=null&&id.equals(a.id)){found.add(a);break;}showAppsDialog("Recently Viewed",found,"No recently viewed apps yet.");}
    private void showAppsDialog(String title,List<AppEntity> apps,String empty){List<String> names=new ArrayList<>();for(AppEntity a:apps)names.add(a.getSafeName());new AlertDialog.Builder(requireContext()).setTitle(title).setMessage(names.isEmpty()?empty:android.text.TextUtils.join("\n",names)).setPositiveButton("OK",null).show();}
    private void showCollections(){List<String> names=user.getCollections();String message=names.isEmpty()?"Create collections to organize apps you like.":android.text.TextUtils.join("\n",names);new AlertDialog.Builder(requireContext()).setTitle("My Collections").setMessage(message).setNegativeButton("Close",null).setPositiveButton("＋ Create",(d,w)->createCollection()).show();}
    private void createCollection(){EditText e=new EditText(requireContext());e.setHint("Collection name");new AlertDialog.Builder(requireContext()).setTitle("New Collection").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String n=e.getText().toString().trim();if(!n.isEmpty()){user.addCollection(n);Toast.makeText(requireContext(),"Collection created",Toast.LENGTH_SHORT).show();}}).show();}
    private void suggestApp(){Intent email=new Intent(Intent.ACTION_SENDTO,Uri.parse("mailto:"));email.putExtra(Intent.EXTRA_SUBJECT,"AppWorld App Suggestion");try{startActivity(Intent.createChooser(email,"Suggest an App"));}catch(Exception e){Toast.makeText(requireContext(),"Email app not available",Toast.LENGTH_SHORT).show();}}
    private void showAbout(){new AlertDialog.Builder(requireContext()).setTitle("About AppWorld").setMessage("AppWorld is an apps and websites directory that helps you discover useful digital tools in one place.").setPositiveButton("OK",null).show();}
    private void refreshApps(){if(b==null)return;b.textProfileStatus.setText("Refreshing app list…");SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){@Override public void success(List<AppEntity> apps){if(isAdded()&&b!=null){update();b.textProfileStatus.setText("App list updated");}}@Override public void error(String message,List<AppEntity> apps){if(isAdded()&&b!=null){update();b.textProfileStatus.setText(message==null?"Could not refresh. Showing saved apps.":message);}}});}
    private void update(){if(b==null)return;b.textProfileApps.setText("Total apps & websites: "+SupabaseAppsRepository.getInstance().getCache().size());b.textProfileFavorites.setText("My favorites: "+FavoritesManager.getInstance().getFavoriteIds().size());b.textProfileName.setText(user.getName()); if (SupabaseAuthManager.get().isSignedIn()) { b.btnAccount.setText("✓  "+SupabaseAuthManager.get().getEmail()); loadCloudProfile(); } else b.btnAccount.setText("🔐  Sign In / Create Account");String photo=user.getPhoto();if(photo!=null&&!photo.isEmpty())Glide.with(this).load(Uri.parse(photo)).placeholder(R.drawable.appworld_logo).circleCrop().into(b.profileAvatar);else b.profileAvatar.setImageResource(R.drawable.appworld_logo);}
    private void loadCloudProfile(){SupabaseSocialRepository.get().getMyProfile((ok,data)->{if(!ok||!isAdded())return;try{org.json.JSONArray a=new org.json.JSONArray(data);if(a.length()==0)return;org.json.JSONObject p=a.getJSONObject(0);String name=p.optString("display_name","");String avatar=p.optString("avatar_url","");requireActivity().runOnUiThread(()->{if(b!=null&&!name.isEmpty())b.textProfileName.setText(name);});if(!avatar.isEmpty()&&!avatar.startsWith("http")){SupabaseSocialRepository.get().createSignedMediaUrl(avatar,(signedOk,signedData)->{if(!signedOk||!isAdded())return;try{String signed=new org.json.JSONObject(signedData).optString("signedURL","");if(signed.startsWith("/"))signed=com.appworld.directory.BuildConfig.SUPABASE_URL+signed;final String imageUrl=signed;requireActivity().runOnUiThread(()->{if(b!=null)Glide.with(this).load(imageUrl).placeholder(R.drawable.appworld_logo).circleCrop().into(b.profileAvatar);});}catch(Exception ignored){}});}else if(!avatar.isEmpty()){requireActivity().runOnUiThread(()->{if(b!=null)Glide.with(this).load(avatar).placeholder(R.drawable.appworld_logo).circleCrop().into(b.profileAvatar);});}}catch(Exception ignored){}}); }
    @Override public void onDestroyView(){super.onDestroyView();b=null;}
}
