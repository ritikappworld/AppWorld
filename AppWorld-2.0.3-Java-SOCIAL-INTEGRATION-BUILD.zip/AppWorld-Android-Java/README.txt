APPWORLD ANDROID JAVA - 2.0.3 SOCIAL INTEGRATION BUILD

Platform: Native Android Java (not Kotlin), min API 21, compile/target SDK 34.
Application ID: com.appworld.directory
Version: 2.0.3 (versionCode 6)
Android Gradle Plugin: 8.8.2; Gradle: 8.10.2; JDK: 17; Java source compatibility: 8.

PRESERVED DIRECTORY FEATURES
- Supabase public.apps REST loading, local cache and starter fallback.
- App details, logos, official website / store / installed-app opening.
- Search, categories, filters, local favorites, recently viewed and collections.
- Home, Categories, Search, Favorites, Profile, Settings, Reels and Chats navigation.

SOCIAL CLIENT INTEGRATION
- Supabase email/password authentication.
- Profile read/update and private Storage avatar upload/signed URL display.
- People search and follow/unfollow.
- Private/group conversation creation, message history and sending.
- Supabase Realtime WebSocket subscription for messages and reels.
- Video selection, upload to private Storage, reels metadata/feed and signed playback URL.
- Reel like/unlike, comments and Android share sheet.
- In-app notifications for follows, reel likes/comments and messages.

SUPABASE CONFIGURATION
Read SUPABASE-SETUP-PRIVATE-CONFIG.txt before configuring the project.
No credentials are embedded in this ZIP. The app cannot connect to your actual project until you privately configure its Project URL and public anon/publishable key. NEVER use service_role or secret keys in an Android app.
Run APPWORLD-2.0.3-AUTH-FOUNDATION.sql and APPWORLD-2.0-SOCIAL-SETUP.sql in your existing Supabase project after taking a backup. The social SQL adds social tables and policies; it is not intended to replace public.apps.

BUILD
GitHub Actions workflow: .github/workflows/build-apk.yml
Expected artifact: AppWorld-2.0.3-debug-apk

VERIFICATION STATUS
- ZIP integrity and Android XML well-formedness are checked.
- A successful Android Gradle/APK build has NOT been verified in this environment (Android SDK/Gradle unavailable).
- No live Supabase project was available for remote SQL, RLS, Storage, Auth, or Realtime testing.
- Review SUPABASE-SETUP-PRIVATE-CONFIG.txt for limitations and pre-launch checks. This is not a production security certification.
