-- AppWorld 2.0 social foundation (Supabase SQL Editor)
-- Run in the existing project. Uses Supabase Auth; NEVER put service_role keys in Android.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default '',
  avatar_url text,
  bio text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_follows (
  follower_id uuid not null references public.profiles(id) on delete cascade,
  following_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (follower_id, following_id),
  constraint user_follows_no_self check (follower_id <> following_id)
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  title text,
  is_group boolean not null default false,
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);
create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text,
  media_url text,
  created_at timestamptz not null default now(),
  constraint messages_body_or_media check (nullif(trim(coalesce(body,'')), '') is not null or media_url is not null)
);

create table if not exists public.reels (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  video_url text not null,
  caption text not null default '',
  created_at timestamptz not null default now()
);
create table if not exists public.reel_likes (
  reel_id uuid not null references public.reels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (reel_id, user_id)
);
create table if not exists public.reel_comments (
  id uuid primary key default gen_random_uuid(),
  reel_id uuid not null references public.reels(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check (length(trim(body)) > 0),
  created_at timestamptz not null default now()
);

create index if not exists messages_conversation_created_idx on public.messages(conversation_id, created_at desc);
create index if not exists reels_created_idx on public.reels(created_at desc);
create index if not exists follows_following_idx on public.user_follows(following_id);

-- Automatically create a profile for every newly registered Auth user.
create or replace function public.handle_new_appworld_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, username, display_name)
  values (new.id,
          null,
          coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'name', ''))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created_appworld on auth.users;
create trigger on_auth_user_created_appworld after insert on auth.users
for each row execute procedure public.handle_new_appworld_user();

alter table public.profiles enable row level security;
alter table public.user_follows enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;
alter table public.reels enable row level security;
alter table public.reel_likes enable row level security;
alter table public.reel_comments enable row level security;

-- SECURITY DEFINER helpers avoid recursive RLS checks between membership and conversation rows.
create or replace function public.appworld_is_conversation_member(p_conversation_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversation_members m
                 where m.conversation_id = p_conversation_id and m.user_id = auth.uid());
$$;
create or replace function public.appworld_is_conversation_creator(p_conversation_id uuid)
returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.conversations c
                 where c.id = p_conversation_id and c.created_by = auth.uid());
$$;

drop policy if exists "Profiles are readable by signed-in users" on public.profiles;
create policy "Profiles are readable by signed-in users" on public.profiles for select to authenticated using (true);
drop policy if exists "Users update own profile" on public.profiles;
create policy "Users update own profile" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
drop policy if exists "Users insert own profile" on public.profiles;
create policy "Users insert own profile" on public.profiles for insert to authenticated with check (id = auth.uid());

drop policy if exists "Follow rows readable by signed-in users" on public.user_follows;
create policy "Follow rows readable by signed-in users" on public.user_follows for select to authenticated using (true);
drop policy if exists "Follow own account" on public.user_follows;
create policy "Follow own account" on public.user_follows for insert to authenticated with check (follower_id = auth.uid() and following_id <> auth.uid());
drop policy if exists "Unfollow own account" on public.user_follows;
create policy "Unfollow own account" on public.user_follows for delete to authenticated using (follower_id = auth.uid());

drop policy if exists "Members read their conversations" on public.conversations;
create policy "Members read their conversations" on public.conversations for select to authenticated using (public.appworld_is_conversation_member(id));
drop policy if exists "Signed-in users create conversations" on public.conversations;
create policy "Signed-in users create conversations" on public.conversations for insert to authenticated with check (created_by = auth.uid());
drop policy if exists "Members see conversation membership" on public.conversation_members;
create policy "Members see conversation membership" on public.conversation_members for select to authenticated using (public.appworld_is_conversation_member(conversation_id));
drop policy if exists "Conversation creator adds members" on public.conversation_members;
create policy "Conversation creator adds members" on public.conversation_members for insert to authenticated with check (public.appworld_is_conversation_creator(conversation_id));
drop policy if exists "Members read messages" on public.messages;
create policy "Members read messages" on public.messages for select to authenticated using (public.appworld_is_conversation_member(conversation_id));
drop policy if exists "Members send messages as themselves" on public.messages;
create policy "Members send messages as themselves" on public.messages for insert to authenticated with check (sender_id = auth.uid() and public.appworld_is_conversation_member(conversation_id));

drop policy if exists "Signed-in users read reels" on public.reels;
create policy "Signed-in users read reels" on public.reels for select to authenticated using (true);
drop policy if exists "Users publish own reels" on public.reels;
create policy "Users publish own reels" on public.reels for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users delete own reels" on public.reels;
create policy "Users delete own reels" on public.reels for delete to authenticated using (user_id = auth.uid());
drop policy if exists "Signed-in users read reel likes" on public.reel_likes;
create policy "Signed-in users read reel likes" on public.reel_likes for select to authenticated using (true);
drop policy if exists "Users like as themselves" on public.reel_likes;
create policy "Users like as themselves" on public.reel_likes for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users remove own likes" on public.reel_likes;
create policy "Users remove own likes" on public.reel_likes for delete to authenticated using (user_id = auth.uid());
drop policy if exists "Signed-in users read reel comments" on public.reel_comments;
create policy "Signed-in users read reel comments" on public.reel_comments for select to authenticated using (true);
drop policy if exists "Users comment as themselves" on public.reel_comments;
create policy "Users comment as themselves" on public.reel_comments for insert to authenticated with check (user_id = auth.uid());
drop policy if exists "Users delete own comments" on public.reel_comments;
create policy "Users delete own comments" on public.reel_comments for delete to authenticated using (user_id = auth.uid());

-- Private media bucket. Use paths prefixed by the authenticated user's UUID.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('appworld-social', 'appworld-social', false, 52428800,
        array['image/jpeg','image/png','image/webp','video/mp4','video/quicktime'])
on conflict (id) do nothing;
drop policy if exists "Users upload their own AppWorld media" on storage.objects;
create policy "Users upload their own AppWorld media" on storage.objects for insert to authenticated
with check (bucket_id = 'appworld-social' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Signed-in users read AppWorld media" on storage.objects;
create policy "Signed-in users read AppWorld media" on storage.objects for select to authenticated
using (bucket_id = 'appworld-social');
drop policy if exists "Users delete their own AppWorld media" on storage.objects;
create policy "Users delete their own AppWorld media" on storage.objects for delete to authenticated
using (bucket_id = 'appworld-social' and (storage.foldername(name))[1] = auth.uid()::text);

-- Realtime publication additions are guarded so rerunning this script is safe.
do $$ begin
  alter publication supabase_realtime add table public.messages;
exception when duplicate_object then null; when undefined_object then null; end $$;
do $$ begin
  alter publication supabase_realtime add table public.reels;
exception when duplicate_object then null; when undefined_object then null; end $$;

-- AppWorld Android integration additions (safe to re-run).
-- Create a conversation and add its creator plus selected members atomically.
create or replace function public.appworld_create_conversation(
  p_title text,
  p_is_group boolean,
  p_member_ids uuid[]
) returns uuid
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_conversation_id uuid;
  v_member uuid;
begin
  if auth.uid() is null then
    raise exception 'Authentication required';
  end if;
  insert into public.conversations(title, is_group, created_by)
  values (nullif(trim(coalesce(p_title, '')), ''), coalesce(p_is_group, false), auth.uid())
  returning id into v_conversation_id;

  insert into public.conversation_members(conversation_id, user_id)
  values (v_conversation_id, auth.uid())
  on conflict do nothing;

  foreach v_member in array coalesce(p_member_ids, array[]::uuid[]) loop
    if v_member <> auth.uid() then
      insert into public.conversation_members(conversation_id, user_id)
      values (v_conversation_id, v_member)
      on conflict do nothing;
    end if;
  end loop;
  return v_conversation_id;
end;
$$;
revoke all on function public.appworld_create_conversation(text, boolean, uuid[]) from public;
grant execute on function public.appworld_create_conversation(text, boolean, uuid[]) to authenticated;

grant usage on schema public to authenticated;
grant select, insert, update on public.profiles to authenticated;
grant select, insert, delete on public.user_follows to authenticated;
grant select, insert on public.conversations to authenticated;
grant select, insert on public.conversation_members to authenticated;
grant select, insert on public.messages to authenticated;
grant select, insert, delete on public.reels to authenticated;
grant select, insert, delete on public.reel_likes to authenticated;
grant select, insert, delete on public.reel_comments to authenticated;

-- In-app notifications for social activity.
create table if not exists public.appworld_notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references public.profiles(id) on delete cascade,
  actor_id uuid references public.profiles(id) on delete set null,
  notification_type text not null check (notification_type in ('follow','reel_like','reel_comment','message')),
  reference_id uuid,
  body text not null default '',
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists appworld_notifications_recipient_created_idx on public.appworld_notifications(recipient_id, created_at desc);
alter table public.appworld_notifications enable row level security;
drop policy if exists "Users read their notifications" on public.appworld_notifications;
create policy "Users read their notifications" on public.appworld_notifications for select to authenticated using (recipient_id = auth.uid());
drop policy if exists "Users mark own notifications read" on public.appworld_notifications;
create policy "Users mark own notifications read" on public.appworld_notifications for update to authenticated using (recipient_id = auth.uid()) with check (recipient_id = auth.uid());
grant select, update on public.appworld_notifications to authenticated;

create or replace function public.appworld_notify_follow() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.appworld_notifications(recipient_id,actor_id,notification_type,reference_id,body)
  values(new.following_id,new.follower_id,'follow',new.follower_id,'started following you');
  return new;
end; $$;
drop trigger if exists appworld_follow_notification on public.user_follows;
create trigger appworld_follow_notification after insert on public.user_follows for each row execute procedure public.appworld_notify_follow();

create or replace function public.appworld_notify_reel_activity() returns trigger
language plpgsql security definer set search_path = '' as $$
declare v_owner uuid; v_actor uuid; v_type text; v_body text;
begin
  select user_id into v_owner from public.reels where id = new.reel_id;
  v_actor := new.user_id;
  if tg_table_name = 'reel_likes' then v_type := 'reel_like'; v_body := 'liked your reel'; else v_type := 'reel_comment'; v_body := 'commented on your reel'; end if;
  if v_owner is not null and v_owner <> v_actor then
    insert into public.appworld_notifications(recipient_id,actor_id,notification_type,reference_id,body) values(v_owner,v_actor,v_type,new.reel_id,v_body);
  end if;
  return new;
end; $$;
drop trigger if exists appworld_reel_like_notification on public.reel_likes;
create trigger appworld_reel_like_notification after insert on public.reel_likes for each row execute procedure public.appworld_notify_reel_activity();
drop trigger if exists appworld_reel_comment_notification on public.reel_comments;
create trigger appworld_reel_comment_notification after insert on public.reel_comments for each row execute procedure public.appworld_notify_reel_activity();

create or replace function public.appworld_notify_message() returns trigger
language plpgsql security definer set search_path = '' as $$
declare v_member uuid;
begin
  for v_member in select user_id from public.conversation_members where conversation_id = new.conversation_id and user_id <> new.sender_id loop
    insert into public.appworld_notifications(recipient_id,actor_id,notification_type,reference_id,body)
    values(v_member,new.sender_id,'message',new.id,'sent you a message');
  end loop;
  return new;
end; $$;
drop trigger if exists appworld_message_notification on public.messages;
create trigger appworld_message_notification after insert on public.messages for each row execute procedure public.appworld_notify_message();

do $$ begin
  alter publication supabase_realtime add table public.appworld_notifications;
exception when duplicate_object then null; when undefined_object then null; end $$;

-- Backfill profile rows for accounts that existed before the profile trigger was installed.
insert into public.profiles(id, display_name)
select u.id, coalesce(u.raw_user_meta_data->>'display_name', u.raw_user_meta_data->>'name', '')
from auth.users u
on conflict (id) do nothing;
