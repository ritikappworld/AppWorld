-- AppWorld 2.0.3 Auth + profile foundation (safe to run more than once)
-- Run in Supabase SQL Editor. This does not modify public.apps.
-- Email/password provider must also be enabled in Supabase Dashboard > Authentication > Providers.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text unique,
  display_name text not null default '',
  avatar_url text,
  bio text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles add column if not exists username text;
alter table public.profiles add column if not exists display_name text not null default '';
alter table public.profiles add column if not exists avatar_url text;
alter table public.profiles add column if not exists bio text not null default '';
alter table public.profiles add column if not exists created_at timestamptz not null default now();
alter table public.profiles add column if not exists updated_at timestamptz not null default now();

create or replace function public.appworld_create_profile_for_auth_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'name', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists appworld_auth_user_profile_created on auth.users;
create trigger appworld_auth_user_profile_created
after insert on auth.users
for each row execute procedure public.appworld_create_profile_for_auth_user();

alter table public.profiles enable row level security;
drop policy if exists "AppWorld signed-in users can read profiles" on public.profiles;
create policy "AppWorld signed-in users can read profiles"
on public.profiles for select to authenticated using (true);
drop policy if exists "AppWorld users can insert own profile" on public.profiles;
create policy "AppWorld users can insert own profile"
on public.profiles for insert to authenticated with check (id = auth.uid());
drop policy if exists "AppWorld users can update own profile" on public.profiles;
create policy "AppWorld users can update own profile"
on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

grant select, insert, update on public.profiles to authenticated;
