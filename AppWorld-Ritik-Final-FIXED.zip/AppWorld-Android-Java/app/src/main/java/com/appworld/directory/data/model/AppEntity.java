package com.appworld.directory.data.model;

import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.JsonAdapter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AppEntity implements Serializable {
    @SerializedName("id") public String id;
    @SerializedName("name") public String name;
    @SerializedName("logo") public String logo;
    @SerializedName("description") public String description;
    @SerializedName("category") public String category;
    @SerializedName("type") public String type;
    @SerializedName("pricing") public String pricing;
    @SerializedName("rating") public double rating;
    @SerializedName("platforms") @JsonAdapter(StringListAdapter.class) public List<String> platforms = new ArrayList<>();
    @SerializedName("official_website") public String officialWebsite;
    @SerializedName("google_play_url") public String googlePlayUrl;
    @SerializedName("app_store_url") public String appStoreUrl;
    @SerializedName("features") @JsonAdapter(StringListAdapter.class) public List<String> features = new ArrayList<>();
    @SerializedName("screenshots") @JsonAdapter(StringListAdapter.class) public List<String> screenshots = new ArrayList<>();
    @SerializedName("verified") public boolean verified;
    @SerializedName("date_added") public String dateAdded;
    @SerializedName("created_at") public String createdAt;
}


// Supabase rows may store these fields as either a JSON array or a single text value.
// This adapter accepts both formats so one inconsistent row cannot break the whole app list.
class StringListAdapter implements com.google.gson.JsonDeserializer<List<String>> {
    @Override
    public List<String> deserialize(com.google.gson.JsonElement json,
            java.lang.reflect.Type typeOfT,
            com.google.gson.JsonDeserializationContext context)
            throws com.google.gson.JsonParseException {
        List<String> result = new ArrayList<>();
        if (json == null || json.isJsonNull()) return result;
        if (json.isJsonArray()) {
            for (com.google.gson.JsonElement item : json.getAsJsonArray()) {
                if (item != null && !item.isJsonNull()) result.add(item.getAsString());
            }
        } else if (json.isJsonPrimitive()) {
            String value = json.getAsString();
            if (!value.trim().isEmpty()) result.add(value);
        }
        return result;
    }
}
