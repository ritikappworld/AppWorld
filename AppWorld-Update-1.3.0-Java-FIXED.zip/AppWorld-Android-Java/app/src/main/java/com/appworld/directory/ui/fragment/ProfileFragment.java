package com.appworld.directory.ui.fragment;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.bumptech.glide.Glide;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.local.ProfileManager;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.FragmentProfileBinding;
import com.appworld.directory.ui.MainActivity;

public class ProfileFragment extends Fragment {
    private FragmentProfileBinding b;
    private ActivityResultLauncher<String[]> photoPicker;

    @Override public void onCreate(@Nullable Bundle state) {
        super.onCreate(state);
        photoPicker = registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri != null && isAdded() && b != null) {
                try { requireContext().getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) { }
                ProfileManager.getInstance().savePhotoUri(uri.toString());
                showProfile();
            }
        });
    }

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        b = FragmentProfileBinding.inflate(inflater, container, false);
        showProfile(); update();
        b.imageProfilePhoto.setOnClickListener(v -> choosePhoto());
        b.btnMyProfile.setOnClickListener(v -> editProfile());
        b.btnMyFavorites.setOnClickListener(v -> { if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).selectFavorites(); });
        b.btnRefreshProfile.setOnClickListener(v -> refreshApps());
        b.btnSettings.setOnClickListener(v -> new AlertDialog.Builder(requireContext()).setTitle("Settings")
                .setItems(new String[]{"Refresh app list", "Change profile picture", "App information"}, (d, which) -> {
                    if (which == 0) refreshApps(); else if (which == 1) choosePhoto(); else showAbout();
                }).show());
        b.btnAbout.setOnClickListener(v -> showAbout());
        b.btnPrivacy.setOnClickListener(v -> new AlertDialog.Builder(requireContext()).setTitle("Privacy Policy")
                .setMessage("Your profile details, profile picture selection and favorites are stored locally on this device. This update does not create an online account or upload your profile information. App and website directory data is retrieved from AppWorld's configured data source.")
                .setPositiveButton("OK", null).show());
        b.btnContact.setOnClickListener(v -> {
            Intent email = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")); email.putExtra(Intent.EXTRA_SUBJECT, "AppWorld Support");
            try { startActivity(Intent.createChooser(email, "Contact AppWorld")); } catch (ActivityNotFoundException e) { Toast.makeText(requireContext(), "No email app found", Toast.LENGTH_SHORT).show(); }
        });
        b.btnRate.setOnClickListener(v -> {
            Uri market = Uri.parse("market://details?id=" + requireContext().getPackageName());
            try { startActivity(new Intent(Intent.ACTION_VIEW, market)); } catch (ActivityNotFoundException e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + requireContext().getPackageName()))); }
        });
        try { String version = requireContext().getPackageManager().getPackageInfo(requireContext().getPackageName(), 0).versionName; b.textAppVersion.setText("App Version " + version); }
        catch (Exception ignored) { b.textAppVersion.setText("App Version"); }
        return b.getRoot();
    }

    private void choosePhoto() { if (photoPicker != null) photoPicker.launch(new String[]{"image/*"}); }

    private void editProfile() {
        ProfileManager profile = ProfileManager.getInstance();
        LinearLayout form = new LinearLayout(requireContext()); form.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density); form.setPadding(pad, pad / 2, pad, 0);
        EditText name = field("Name", profile.getName(), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText email = field("Email (optional)", profile.getEmail(), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        EditText about = field("About you", profile.getAbout(), InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        form.addView(name); form.addView(email); form.addView(about);
        new AlertDialog.Builder(requireContext()).setTitle("Edit Profile").setView(form)
                .setPositiveButton("Save", (d, w) -> {
                    String value = name.getText().toString().trim();
                    if (value.isEmpty()) value = "AppWorld User";
                    profile.save(value, email.getText().toString(), about.getText().toString()); showProfile();
                    Toast.makeText(requireContext(), "Profile saved on this device", Toast.LENGTH_SHORT).show();
                }).setNegativeButton("Cancel", null).show();
    }

    private EditText field(String hint, String value, int inputType) {
        EditText e = new EditText(requireContext()); e.setSingleLine(false); e.setHint(hint); e.setText(value); e.setInputType(inputType);
        e.setPadding(0, 10, 0, 10); return e;
    }

    private void showProfile() {
        if (b == null) return; ProfileManager p = ProfileManager.getInstance();
        b.textProfileName.setText(p.getName());
        b.textProfileEmail.setText(p.getEmail().isEmpty() ? p.getAbout() : p.getEmail());
        String photo = p.getPhotoUri();
        if (!photo.isEmpty()) Glide.with(this).load(Uri.parse(photo)).placeholder(com.appworld.directory.R.drawable.appworld_logo).error(com.appworld.directory.R.drawable.appworld_logo).into(b.imageProfilePhoto);
        else b.imageProfilePhoto.setImageResource(com.appworld.directory.R.drawable.appworld_logo);
    }

    private void showAbout() { new AlertDialog.Builder(requireContext()).setTitle("About AppWorld")
            .setMessage("AppWorld is an apps and websites directory that helps you discover useful digital tools in one place.")
            .setPositiveButton("OK", null).show(); }

    private void refreshApps() {
        if (b == null) return; b.textProfileStatus.setText("Refreshing app list…");
        SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback() {
            @Override public void success(java.util.List<com.appworld.directory.data.model.AppEntity> apps) { if (isAdded() && b != null) { update(); b.textProfileStatus.setText("App list updated"); } }
            @Override public void error(String message, java.util.List<com.appworld.directory.data.model.AppEntity> apps) { if (isAdded() && b != null) { update(); b.textProfileStatus.setText(message == null ? "Could not refresh. Showing saved apps." : message); } }
        });
    }
    private void update() { if (b == null) return; b.textProfileApps.setText("Total apps & websites: " + SupabaseAppsRepository.getInstance().getCache().size()); b.textProfileFavorites.setText("My favorites: " + FavoritesManager.getInstance().getFavoriteIds().size()); }
    @Override public void onResume() { super.onResume(); if (b != null) { showProfile(); update(); } }
    @Override public void onDestroyView() { super.onDestroyView(); b = null; }
}
