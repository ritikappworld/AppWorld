package com.appworld.directory.data.supabase;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import com.appworld.directory.data.model.AppEntity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class SupabaseAppsRepository {
    private static volatile SupabaseAppsRepository instance;
    private final String baseUrl, key;
    private final OkHttpClient client;
    private final Gson gson = new Gson();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final SharedPreferences prefs;
    private volatile List<AppEntity> cache = new ArrayList<>();

    public interface Callback { void success(List<AppEntity> apps); void error(String message, List<AppEntity> fallback); }

    private SupabaseAppsRepository(Context context, String url, String anonKey) {
        baseUrl = url == null ? "" : url.trim().replaceAll("/+$", "");
        key = anonKey == null ? "" : anonKey.trim();
        prefs = context.getApplicationContext().getSharedPreferences("appworld_data", Context.MODE_PRIVATE);
        client = new OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(20, TimeUnit.SECONDS).build();
        String saved = prefs.getString("apps_json", "");
        if (!saved.isEmpty()) {
            try { Type t = new TypeToken<List<AppEntity>>(){}.getType(); List<AppEntity> old = gson.fromJson(saved, t); if (old != null) cache = old; }
            catch (Exception ignored) { cache = new ArrayList<>(); }
        }
    }
    public static synchronized void init(Context c, String url, String key) { if (instance == null) instance = new SupabaseAppsRepository(c, url, key); }
    public static SupabaseAppsRepository getInstance() { return instance; }
    public List<AppEntity> getCache() { return new ArrayList<>(cache); }

    public void fetchApps(Callback callback) {
        if (callback == null) return;
        if (!isConfigured()) { main.post(() -> callback.error("Supabase URL / anon key set nahi hai. README dekhein.", getCache())); return; }
        HttpUrl url = HttpUrl.parse(baseUrl + "/rest/v1/apps");
        if (url == null) { main.post(() -> callback.error("Supabase URL galat hai.", getCache())); return; }
        HttpUrl requestUrl = url.newBuilder().addQueryParameter("select", "*").addQueryParameter("order", "rating.desc.nullslast").build();
        Request request = new Request.Builder().url(requestUrl).header("apikey", key).header("Authorization", "Bearer " + key).header("Accept", "application/json").get().build();
        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, IOException e) { String msg = e.getMessage() == null ? "Network connection failed" : e.getMessage(); main.post(() -> callback.error(msg, getCache())); }
            @Override public void onResponse(Call call, Response response) {
                String bodyText = "";
                try (ResponseBody body = response.body()) {
                    if (body != null) bodyText = body.string();
                    if (!response.isSuccessful()) {
                        String message = "Supabase HTTP " + response.code() + (bodyText.isEmpty() ? "" : ": " + bodyText);
                        main.post(() -> callback.error(message, getCache())); return;
                    }
                    Type type = new TypeToken<List<AppEntity>>(){}.getType();
                    List<AppEntity> rows = gson.fromJson(bodyText, type);
                    if (rows == null) rows = new ArrayList<>();
                    List<AppEntity> clean = new ArrayList<>();
                    for (AppEntity app : rows) if (app != null && app.name != null && !app.name.trim().isEmpty()) clean.add(app);
                    cache = Collections.unmodifiableList(clean);
                    prefs.edit().putString("apps_json", gson.toJson(clean)).apply();
                    List<AppEntity> result = getCache();
                    main.post(() -> callback.success(result));
                } catch (Exception e) {
                    String msg = "Data read nahi ho paya: " + (e.getMessage() == null ? "invalid response" : e.getMessage());
                    main.post(() -> callback.error(msg, getCache()));
                }
            }
        });
    }
    private boolean isConfigured() {
        return baseUrl.startsWith("https://") && !baseUrl.contains("your-project-ref") && !key.isEmpty() && !key.startsWith("YOUR_");
    }
}
