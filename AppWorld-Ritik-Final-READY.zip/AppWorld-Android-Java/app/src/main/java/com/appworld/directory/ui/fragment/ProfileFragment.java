package com.appworld.directory.ui.fragment;
import android.os.Bundle;import android.view.*;import androidx.annotation.*;import androidx.fragment.app.Fragment;import com.appworld.directory.data.local.FavoritesManager;import com.appworld.directory.data.supabase.SupabaseAppsRepository;import com.appworld.directory.databinding.FragmentProfileBinding;
public class ProfileFragment extends Fragment {
 private FragmentProfileBinding b;
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){b=FragmentProfileBinding.inflate(i,c,false);update();b.btnRefreshProfile.setOnClickListener(v->{if(b!=null)b.textProfileStatus.setText("Refreshing...");SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){public void success(java.util.List<com.appworld.directory.data.model.AppEntity>a){if(isAdded()&&b!=null)update();}public void error(String m,java.util.List<com.appworld.directory.data.model.AppEntity>a){if(isAdded()&&b!=null){update();b.textProfileStatus.setText(m);}}});});return b.getRoot();}
 private void update(){if(b==null)return;b.textProfileApps.setText("Available apps & websites: "+SupabaseAppsRepository.getInstance().getCache().size());b.textProfileFavorites.setText("Your favorites: "+FavoritesManager.getInstance().getFavoriteIds().size());b.textProfileStatus.setText("AppWorld directory");}
 @Override public void onResume(){super.onResume();if(b!=null)update();}
 @Override public void onDestroyView(){super.onDestroyView();b=null;}
}
