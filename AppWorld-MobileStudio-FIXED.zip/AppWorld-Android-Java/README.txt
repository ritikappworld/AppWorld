# AppWorld Android Java

Complete starter Android project for AppWorld.

## Before building
Open `gradle.properties` and replace:
- SUPABASE_URL
- SUPABASE_ANON_KEY

Use only your Supabase project URL and anon/publishable client key. Do not put a service-role/secret key in the app.

The app reads `public.apps` through the Supabase REST API.
