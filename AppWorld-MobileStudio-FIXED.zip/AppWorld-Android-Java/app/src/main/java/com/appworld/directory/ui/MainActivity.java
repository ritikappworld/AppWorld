package com.appworld.directory.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.appworld.directory.R;
import com.appworld.directory.databinding.ActivityMainBinding;
import com.appworld.directory.ui.fragment.*;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding b;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        b = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        show(new HomeFragment());
        b.bottomNavigation.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_home) show(new HomeFragment());
            else if (id == R.id.nav_categories) show(new CategoriesFragment());
            else if (id == R.id.nav_search) show(new SearchFragment());
            else if (id == R.id.nav_favorites) show(new FavoritesFragment());
            else if (id == R.id.nav_profile) show(new ProfileFragment());
            return true;
        });
    }
    private void show(Fragment f) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, f).commit();
    }
    public void openTool(com.appworld.directory.data.model.AppEntity app) {
        android.content.Intent i = new android.content.Intent(this, ToolDetailActivity.class);
        i.putExtra("extra_app", app);
        startActivity(i);
    }
}
