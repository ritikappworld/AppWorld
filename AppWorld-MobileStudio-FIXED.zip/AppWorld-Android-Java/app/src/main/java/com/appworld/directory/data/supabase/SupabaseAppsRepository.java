package com.appworld.directory.data.supabase;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.appworld.directory.data.model.AppEntity;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import okhttp3.*;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class SupabaseAppsRepository {
    private static SupabaseAppsRepository instance;
    private final String baseUrl, key;
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    private final Handler main = new Handler(Looper.getMainLooper());
    private List<AppEntity> cache = new ArrayList<>();

    public interface Callback {
        void success(List<AppEntity> apps);
        void error(String message, List<AppEntity> fallback);
    }

    private SupabaseAppsRepository(Context c, String url, String key) {
        this.baseUrl = url == null ? "" : url.replaceAll("/$", "");
        this.key = key == null ? "" : key;
    }
    public static synchronized void init(Context c, String url, String key) {
        if (instance == null) instance = new SupabaseAppsRepository(c, url, key);
    }
    public static SupabaseAppsRepository getInstance() { return instance; }

    public void fetchApps(Callback cb) {
        if (baseUrl.isEmpty() || key.isEmpty() || key.startsWith("YOUR_")) {
            cb.error("Supabase credentials are not configured.", cache);
            return;
        }
        Request r = new Request.Builder()
                .url(baseUrl + "/rest/v1/apps?select=*&order=rating.desc")
                .addHeader("apikey", key)
                .addHeader("Authorization", "Bearer " + key)
                .addHeader("Accept", "application/json")
                .build();
        client.newCall(r).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, IOException e) {
                main.post(() -> cb.error(e.getMessage() == null ? "Network error" : e.getMessage(), cache));
            }
            @Override public void onResponse(Call call, Response response) throws IOException {
                try (ResponseBody body = response.body()) {
                    if (!response.isSuccessful() || body == null) {
                        main.post(() -> cb.error("Supabase HTTP " + response.code(), cache));
                        return;
                    }
                    Type t = new TypeToken<List<AppEntity>>(){}.getType();
                    List<AppEntity> apps = gson.fromJson(body.string(), t);
                    cache = apps == null ? new ArrayList<>() : apps;
                    main.post(() -> cb.success(cache));
                }
            }
        });
    }
    public List<AppEntity> getCache() { return cache; }
}
