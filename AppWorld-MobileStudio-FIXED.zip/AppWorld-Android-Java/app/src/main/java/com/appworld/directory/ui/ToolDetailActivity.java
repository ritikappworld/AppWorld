package com.appworld.directory.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.appworld.directory.R;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.databinding.ActivityToolDetailBinding;

public class ToolDetailActivity extends AppCompatActivity {
    private ActivityToolDetailBinding b;
    private AppEntity app;
    @Override protected void onCreate(Bundle s) {
        super.onCreate(s);
        b = ActivityToolDetailBinding.inflate(getLayoutInflater());
        setContentView(b.getRoot());
        app = (AppEntity)getIntent().getSerializableExtra("extra_app");
        if (app == null) { finish(); return; }
        b.toolbar.setNavigationOnClickListener(v -> finish());
        b.textAppName.setText(app.name);
        b.textCategory.setText(app.category);
        b.textPricing.setText(app.pricing);
        b.textRating.setText(String.format("%.1f", app.rating));
        b.textDescription.setText(app.description);
        Glide.with(this).load(app.logo).placeholder(R.drawable.ic_app_placeholder).into(b.imageLogo);
        updateFav();
        b.btnFavorite.setOnClickListener(v -> {
            boolean fav = FavoritesManager.getInstance().toggleFavorite(app.id);
            updateFav();
            Toast.makeText(this, fav ? "Added to Favorites" : "Removed from Favorites", Toast.LENGTH_SHORT).show();
        });
        if (app.officialWebsite != null && !app.officialWebsite.isEmpty()) {
            b.btnVisitWebsite.setOnClickListener(v -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(app.officialWebsite))); }
                catch (Exception ignored) {}
            });
        } else b.btnVisitWebsite.setVisibility(View.GONE);
    }
    private void updateFav() {
        b.btnFavorite.setIconResource(FavoritesManager.getInstance().isFavorite(app.id)
                ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline);
    }
}
