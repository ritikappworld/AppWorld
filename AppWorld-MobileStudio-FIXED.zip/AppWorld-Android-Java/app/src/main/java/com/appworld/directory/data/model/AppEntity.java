package com.appworld.directory.data.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class AppEntity implements Serializable {
    @SerializedName("id") public String id;
    @SerializedName("name") public String name;
    @SerializedName("logo") public String logo;
    @SerializedName("description") public String description;
    @SerializedName("category") public String category;
    @SerializedName("type") public String type;
    @SerializedName("pricing") public String pricing;
    @SerializedName("rating") public double rating;
    @SerializedName("platforms") public List<String> platforms = new ArrayList<>();
    @SerializedName("official_website") public String officialWebsite;
    @SerializedName("google_play_url") public String googlePlayUrl;
    @SerializedName("app_store_url") public String appStoreUrl;
    @SerializedName("features") public List<String> features = new ArrayList<>();
    @SerializedName("screenshots") public List<String> screenshots = new ArrayList<>();
    @SerializedName("verified") public boolean verified;
    @SerializedName("date_added") public String dateAdded;
    @SerializedName("created_at") public String createdAt;
}
