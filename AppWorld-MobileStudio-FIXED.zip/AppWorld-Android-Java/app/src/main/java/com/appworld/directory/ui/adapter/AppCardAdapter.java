package com.appworld.directory.ui.adapter;

import android.view.*;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.appworld.directory.R;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.databinding.ItemAppCardBinding;
import java.util.*;

public class AppCardAdapter extends RecyclerView.Adapter<AppCardAdapter.H> {
    public interface Listener { void click(AppEntity a); }
    private List<AppEntity> apps = new ArrayList<>();
    private final Listener listener;
    public AppCardAdapter(Listener l){ listener=l; }
    public void setApps(List<AppEntity> a){ apps=a==null?new ArrayList<>():a; notifyDataSetChanged(); }
    @NonNull public H onCreateViewHolder(@NonNull ViewGroup p,int v){
        return new H(ItemAppCardBinding.inflate(LayoutInflater.from(p.getContext()),p,false));
    }
    public void onBindViewHolder(@NonNull H h,int pos){ h.bind(apps.get(pos)); }
    public int getItemCount(){ return apps.size(); }
    class H extends RecyclerView.ViewHolder {
        ItemAppCardBinding b;
        H(ItemAppCardBinding x){ super(x.getRoot()); b=x; }
        void bind(AppEntity a){
            b.textName.setText(a.name); b.textCategory.setText(a.category);
            b.textPricing.setText(a.pricing); b.textRating.setText(String.format("%.1f",a.rating));
            Glide.with(itemView).load(a.logo).placeholder(R.drawable.ic_app_placeholder).into(b.imageLogo);
            b.btnHeart.setImageResource(FavoritesManager.getInstance().isFavorite(a.id)?R.drawable.ic_heart_filled:R.drawable.ic_heart_outline);
            b.btnHeart.setOnClickListener(v -> {
                boolean f=FavoritesManager.getInstance().toggleFavorite(a.id);
                b.btnHeart.setImageResource(f?R.drawable.ic_heart_filled:R.drawable.ic_heart_outline);
            });
            itemView.setOnClickListener(v -> listener.click(a));
        }
    }
}
