package com.appworld.directory.data.local;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public class FavoritesManager {
    private static FavoritesManager instance;
    private final SharedPreferences prefs;

    private FavoritesManager(Context c) {
        prefs = c.getApplicationContext().getSharedPreferences("appworld_favorites", Context.MODE_PRIVATE);
    }
    public static synchronized void init(Context c) {
        if (instance == null) instance = new FavoritesManager(c);
    }
    public static FavoritesManager getInstance() { return instance; }

    public boolean isFavorite(String id) {
        return id != null && prefs.getStringSet("ids", new HashSet<>()).contains(id);
    }
    public boolean toggleFavorite(String id) {
        if (id == null) return false;
        Set<String> s = new HashSet<>(prefs.getStringSet("ids", new HashSet<>()));
        boolean now = !s.contains(id);
        if (now) s.add(id); else s.remove(id);
        prefs.edit().putStringSet("ids", s).apply();
        return now;
    }
    public Set<String> getFavoriteIds() {
        return new HashSet<>(prefs.getStringSet("ids", new HashSet<>()));
    }
}
