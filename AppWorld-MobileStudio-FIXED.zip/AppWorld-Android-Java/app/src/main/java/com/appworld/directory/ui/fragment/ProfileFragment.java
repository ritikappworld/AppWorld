package com.appworld.directory.ui.fragment;
import android.os.Bundle; import android.view.*; import androidx.fragment.app.Fragment; import com.appworld.directory.databinding.FragmentProfileBinding;
public class ProfileFragment extends Fragment { public View onCreateView(LayoutInflater i,ViewGroup c,Bundle s){ return FragmentProfileBinding.inflate(i,c,false).getRoot(); } }