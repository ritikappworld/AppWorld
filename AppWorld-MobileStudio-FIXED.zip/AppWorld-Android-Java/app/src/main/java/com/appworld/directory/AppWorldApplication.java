package com.appworld.directory;

import android.app.Application;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;

public class AppWorldApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        FavoritesManager.init(this);
        SupabaseAppsRepository.init(this, BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_ANON_KEY);
    }
}
