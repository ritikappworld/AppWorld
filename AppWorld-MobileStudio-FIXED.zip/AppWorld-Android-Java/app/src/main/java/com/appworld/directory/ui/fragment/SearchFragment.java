package com.appworld.directory.ui.fragment;
import android.os.Bundle; import android.view.*; import androidx.fragment.app.Fragment; import com.appworld.directory.databinding.FragmentSearchBinding;
public class SearchFragment extends Fragment { public View onCreateView(LayoutInflater i,ViewGroup c,Bundle s){ return FragmentSearchBinding.inflate(i,c,false).getRoot(); } }