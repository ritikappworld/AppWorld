package com.appworld.directory.ui.fragment;
import android.os.Bundle; import android.view.*; import androidx.fragment.app.Fragment; import com.appworld.directory.R; import com.appworld.directory.data.model.AppEntity; import com.appworld.directory.data.supabase.SupabaseAppsRepository; import com.appworld.directory.databinding.FragmentHomeBinding; import com.appworld.directory.ui.MainActivity; import com.appworld.directory.ui.adapter.AppCardAdapter;
public class HomeFragment extends Fragment {
 private FragmentHomeBinding b; private AppCardAdapter a;
 public View onCreateView(LayoutInflater i,ViewGroup c,Bundle s){ b=FragmentHomeBinding.inflate(i,c,false); a=new AppCardAdapter(x->((MainActivity)requireActivity()).openTool(x)); b.recyclerApps.setAdapter(a); load(); return b.getRoot(); }
 private void load(){ SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){ public void success(java.util.List<AppEntity> x){ a.setApps(x); b.textStatus.setText(x.size()+" tools available"); } public void error(String m,java.util.List<AppEntity> x){ a.setApps(x); b.textStatus.setText(x.isEmpty()?"Connect Supabase to load apps":x.size()+" cached tools"); }}); }
}