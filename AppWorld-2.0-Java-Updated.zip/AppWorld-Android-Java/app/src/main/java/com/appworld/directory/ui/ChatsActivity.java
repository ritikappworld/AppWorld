package com.appworld.directory.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.appworld.directory.databinding.ActivitySocialHubBinding;

/** AppWorld 2.0 chat entry point. No messages are fabricated or stored insecurely. */
public class ChatsActivity extends AppCompatActivity {
    private ActivitySocialHubBinding binding;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        binding = ActivitySocialHubBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.textSocialTitle.setText("AppWorld Chats");
        binding.textSocialSubtitle.setText("Personal chats, group conversations and chat requests.");
        binding.textSocialEmpty.setText("No conversations yet.

Secure messaging, photo sharing, group chats and online status require AppWorld account sign-in and the Supabase 2.0 database setup.");
        binding.btnSocialAction.setText("Back to AppWorld");
        binding.btnSocialAction.setOnClickListener(v -> finish());
        binding.btnSocialBack.setOnClickListener(v -> finish());
    }
}
