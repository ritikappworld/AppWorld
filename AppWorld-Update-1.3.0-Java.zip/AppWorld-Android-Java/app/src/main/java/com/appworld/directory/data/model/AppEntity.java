package com.appworld.directory.data.model;

import com.google.gson.annotations.SerializedName;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.*;
import java.io.Serializable;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class AppEntity implements Serializable {
    @SerializedName("id") public String id;
    @SerializedName("name") public String name;
    @SerializedName("logo") public String logo;
    @SerializedName("description") public String description;
    @SerializedName("category") public String category;
    @SerializedName("type") public String type;
    @SerializedName("pricing") public String pricing;
    @SerializedName("rating") public double rating;
    @SerializedName("platforms") @JsonAdapter(StringListAdapter.class) public List<String> platforms = new ArrayList<>();
    @SerializedName("official_website") public String officialWebsite;
    @SerializedName("google_play_url") public String googlePlayUrl;
    @SerializedName("app_store_url") public String appStoreUrl;
    @SerializedName("features") @JsonAdapter(StringListAdapter.class) public List<String> features = new ArrayList<>();
    @SerializedName("screenshots") @JsonAdapter(StringListAdapter.class) public List<String> screenshots = new ArrayList<>();
    @SerializedName("verified") public boolean verified;
    @SerializedName("date_added") public String dateAdded;
    @SerializedName("created_at") public String createdAt;

    public String getSafeName() { return name == null || name.trim().isEmpty() ? "Unnamed app" : name.trim(); }
    public String getSafeCategory() { return category == null || category.trim().isEmpty() ? "Other" : category.trim(); }
}

class StringListAdapter implements JsonDeserializer<List<String>> {
    @Override public List<String> deserialize(JsonElement json, Type type, JsonDeserializationContext context) throws JsonParseException {
        List<String> out = new ArrayList<>();
        if (json == null || json.isJsonNull()) return out;
        if (json.isJsonArray()) {
            for (JsonElement e : json.getAsJsonArray()) if (e != null && !e.isJsonNull()) out.add(e.getAsString());
        } else if (json.isJsonPrimitive()) {
            String v = json.getAsString(); if (!v.trim().isEmpty()) out.add(v);
        }
        return out;
    }
}
