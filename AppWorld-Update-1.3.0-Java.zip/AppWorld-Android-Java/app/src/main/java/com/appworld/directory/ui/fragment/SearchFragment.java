package com.appworld.directory.ui.fragment;

import android.content.Intent;
import android.speech.RecognizerIntent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;
import androidx.annotation.*;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.appworld.directory.data.local.UserDataManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.FragmentSearchBinding;
import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.*;

public class SearchFragment extends Fragment {
 private static final int VOICE_REQUEST=902;
 private FragmentSearchBinding b; private AppCardAdapter adapter; private List<AppEntity> all=new ArrayList<>(); private String filterMode="all"; private UserDataManager user;
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){
  b=FragmentSearchBinding.inflate(i,c,false);user=UserDataManager.get(requireContext());adapter=new AppCardAdapter(FragmentTools.listener(this));b.recyclerSearch.setLayoutManager(new LinearLayoutManager(requireContext()));b.recyclerSearch.setAdapter(adapter);
  b.editSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int st,int count,int after){}public void onTextChanged(CharSequence x,int st,int before,int count){filter(x.toString());}public void afterTextChanged(Editable e){}});
  b.editSearch.setOnEditorActionListener((v,action,event)->{if(action==EditorInfo.IME_ACTION_SEARCH||action==EditorInfo.IME_ACTION_DONE){user.addSearch(v.getText().toString());((android.view.inputmethod.InputMethodManager)requireContext().getSystemService(android.content.Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);return true;}return false;});
  b.btnFilterAll.setOnClickListener(v->setFilter("all"));b.btnFilterFree.setOnClickListener(v->setFilter("free"));b.btnFilterPaid.setOnClickListener(v->setFilter("paid"));b.btnSearchHistory.setOnClickListener(v->showHistory());b.btnVoiceSearch.setOnClickListener(v->startVoiceSearch());
  all=SupabaseAppsRepository.getInstance().getCache();filter("");SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){public void success(List<AppEntity>a){if(isAdded()&&b!=null){all=a;filter(b.editSearch.getText().toString());}}public void error(String m,List<AppEntity>a){if(isAdded()&&b!=null){all=a;filter(b.editSearch.getText().toString());}}});return b.getRoot();
 }
 private void setFilter(String mode){filterMode=mode;filter(b==null?"":b.editSearch.getText().toString());}
 private void showHistory(){List<String> h=user.getSearchHistory();if(h.isEmpty()){Toast.makeText(requireContext(),"No search history yet",Toast.LENGTH_SHORT).show();return;}String[] items=h.toArray(new String[0]);new AlertDialog.Builder(requireContext()).setTitle("Recent Searches").setItems(items,(d,w)->{if(b!=null)b.editSearch.setText(items[w]);}).setNeutralButton("Clear",(d,w)->{user.clearSearchHistory();Toast.makeText(requireContext(),"History cleared",Toast.LENGTH_SHORT).show();}).setNegativeButton("Close",null).show();}
 private void startVoiceSearch(){try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak an app or website name");startActivityForResult(i,VOICE_REQUEST);}catch(Exception e){Toast.makeText(requireContext(),"Voice search is not available on this device",Toast.LENGTH_SHORT).show();}}
 @Override public void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==VOICE_REQUEST&&result==android.app.Activity.RESULT_OK&&data!=null){ArrayList<String> matches=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(matches!=null&&!matches.isEmpty()&&b!=null){b.editSearch.setText(matches.get(0));b.editSearch.setSelection(b.editSearch.length());user.addSearch(matches.get(0));}}}
 private String join(List<String> values){return values==null?"":android.text.TextUtils.join(" ",values);}
 private void filter(String q){if(b==null)return;String needle=q==null?"":q.trim().toLowerCase(Locale.ROOT);List<AppEntity> out=new ArrayList<>();for(AppEntity a:all){if(a==null)continue;String hay=(a.name+" "+a.category+" "+a.description+" "+a.type+" "+a.pricing+" "+a.officialWebsite+" "+join(a.features)+" "+join(a.platforms)).toLowerCase(Locale.ROOT);boolean matches=needle.isEmpty()||hay.contains(needle);String price=a.pricing==null?"":a.pricing.toLowerCase(Locale.ROOT);if("free".equals(filterMode))matches=matches&&(price.contains("free")||price.contains("open source"));else if("paid".equals(filterMode))matches=matches&&(price.contains("paid")||price.contains("premium"));if(matches)out.add(a);}adapter.setApps(out);b.textSearchEmpty.setVisibility(out.isEmpty()?View.VISIBLE:View.GONE);b.textSearchEmpty.setText(needle.isEmpty()?"No apps available yet.":"No matching apps found.");}
 @Override public void onDestroyView(){super.onDestroyView();b=null;}
}
