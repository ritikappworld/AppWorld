package com.appworld.directory.ui;

import android.net.Uri;
import com.appworld.directory.data.model.AppEntity;
import java.util.Locale;

/** Uses the database logo first; known brands get their official domain favicon as fallback. */
public final class LogoHelper {
    private LogoHelper() {}
    public static String imageFor(AppEntity app) {
        if (app == null) return null;
        if (app.logo != null && app.logo.trim().length() > 0) return app.logo.trim();
        String domain = knownDomain(app.getSafeName());
        if (domain == null) domain = domainFrom(app.officialWebsite);
        if (domain == null) return null;
        return "https://www.google.com/s2/favicons?domain=" + Uri.encode(domain) + "&sz=128";
    }
    /** Called when a database-provided image URL fails to load. */
    public static String fallbackImageFor(AppEntity app) {
        if (app == null) return null;
        String domain = knownDomain(app.getSafeName());
        if (domain == null) domain = domainFrom(app.officialWebsite);
        if (domain == null) return null;
        return "https://www.google.com/s2/favicons?domain=" + Uri.encode(domain) + "&sz=128";
    }
    private static String knownDomain(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        String[][] brands = {
            {"whatsapp","whatsapp.com"},{"instagram","instagram.com"},{"youtube","youtube.com"},
            {"facebook","facebook.com"},{"telegram","telegram.org"},{"chatgpt","chatgpt.com"},
            {"google chrome","google.com"},{"chrome","google.com"},{"gmail","gmail.com"},
            {"google maps","maps.google.com"},{"google drive","drive.google.com"},{"google photos","photos.google.com"},
            {"spotify","spotify.com"},{"netflix","netflix.com"},{"amazon","amazon.in"},{"flipkart","flipkart.com"},
            {"linkedin","linkedin.com"},{"snapchat","snapchat.com"},{"x","x.com"},{"twitter","x.com"},
            {"pinterest","pinterest.com"},{"reddit","reddit.com"},{"discord","discord.com"},{"zoom","zoom.us"},
            {"microsoft teams","teams.microsoft.com"},{"microsoft","microsoft.com"},{"spotify","spotify.com"},
            {"canva","canva.com"},{"capcut","capcut.com"},{"perplexity","perplexity.ai"},{"gemini","gemini.google.com"},
            {"telegram","telegram.org"},{"phonepe","phonepe.com"},{"paytm","paytm.com"},{"gpay","pay.google.com"}
        };
        for (String[] brand : brands) if (n.equals(brand[0]) || n.contains(brand[0])) return brand[1];
        return null;
    }
    private static String domainFrom(String value) {
        if (value == null || value.trim().isEmpty()) return null;
        try {
            String v = value.trim(); if (!v.startsWith("http://") && !v.startsWith("https://")) v = "https://" + v;
            return Uri.parse(v).getHost();
        } catch (Exception ignored) { return null; }
    }
}
