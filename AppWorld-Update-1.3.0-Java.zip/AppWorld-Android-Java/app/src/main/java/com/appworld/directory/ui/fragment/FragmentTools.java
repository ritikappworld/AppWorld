package com.appworld.directory.ui.fragment;
import androidx.fragment.app.Fragment;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.ui.MainActivity;
import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.List;
public final class FragmentTools {
    private FragmentTools() {}
    public static AppCardAdapter.Listener listener(Fragment fragment) {
        return new AppCardAdapter.Listener() {
            @Override public void click(AppEntity app) { if (fragment.getActivity() instanceof MainActivity) ((MainActivity) fragment.getActivity()).openTool(app); }
            @Override public void favoriteChanged(AppEntity app, boolean favorite) { }
        };
    }
    public static void open(Fragment f, AppEntity app) { if (f.getActivity() instanceof MainActivity) ((MainActivity) f.getActivity()).openTool(app); }
}
