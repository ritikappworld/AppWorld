package com.appworld.directory.ui;

import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.target.Target;
import androidx.annotation.Nullable;
import com.appworld.directory.R;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.databinding.ActivityToolDetailBinding;

public class ToolDetailActivity extends AppCompatActivity {
    private ActivityToolDetailBinding b;
    private AppEntity app;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state); b=ActivityToolDetailBinding.inflate(getLayoutInflater()); setContentView(b.getRoot());
        app=(AppEntity)getIntent().getSerializableExtra("extra_app"); if(app==null){finish();return;}
        b.toolbar.setNavigationOnClickListener(v->finish());
        b.textAppName.setText(app.getSafeName()); b.textCategory.setText(app.getSafeCategory());
        b.textPricing.setText(app.pricing==null||app.pricing.trim().isEmpty()?"Pricing not listed":app.pricing);
        b.textRating.setText(app.rating>0?String.format(java.util.Locale.getDefault(),"★ %.1f",app.rating):"Rating not listed");
        b.textDescription.setText(app.description==null||app.description.trim().isEmpty()?"No description available.":app.description);
        loadLogo(); updateFavorite();
        b.btnFavorite.setOnClickListener(v->{boolean added=FavoritesManager.getInstance().toggleFavorite(app.id);updateFavorite();Toast.makeText(this,added?"Added to Favorites":"Removed from Favorites",Toast.LENGTH_SHORT).show();});
        String packageName=packageFor(app.getSafeName());
        if(packageName!=null){b.btnOpenApp.setVisibility(View.VISIBLE);b.btnOpenApp.setOnClickListener(v->openInstalledApp(packageName));}
        String play=valid(app.googlePlayUrl)?app.googlePlayUrl:(packageName==null?"https://play.google.com/store/search?q="+Uri.encode(app.getSafeName())+"&c=apps":"https://play.google.com/store/apps/details?id="+packageName);
        b.btnOpenPlayStore.setVisibility(View.VISIBLE); b.btnOpenPlayStore.setOnClickListener(v->openLink(play));
        if(valid(app.officialWebsite)){b.btnVisitWebsite.setVisibility(View.VISIBLE);b.btnVisitWebsite.setOnClickListener(v->openLink(app.officialWebsite));}
    }
    private void loadLogo(){String primary=LogoHelper.imageFor(app); com.bumptech.glide.RequestBuilder<android.graphics.drawable.Drawable> request=Glide.with(this).load(primary).placeholder(R.drawable.ic_app_placeholder).diskCacheStrategy(DiskCacheStrategy.AUTOMATIC); String fallback=LogoHelper.fallbackImageFor(app); if(fallback!=null&&(primary==null||!fallback.equals(primary)))request=request.error(Glide.with(this).load(fallback));else request=request.error(R.drawable.ic_app_placeholder); request.into(b.imageLogo);}
    private boolean valid(String s){return s!=null&&!s.trim().isEmpty();}
    private String packageFor(String name){String n=name.toLowerCase(java.util.Locale.ROOT);
        if(n.contains("whatsapp"))return "com.whatsapp"; if(n.contains("instagram"))return "com.instagram.android";
        if(n.equals("youtube")||n.startsWith("youtube "))return "com.google.android.youtube"; if(n.contains("facebook"))return "com.facebook.katana";
        if(n.contains("telegram"))return "org.telegram.messenger"; if(n.contains("spotify"))return "com.spotify.music";
        if(n.contains("snapchat"))return "com.snapchat.android"; if(n.contains("chrome"))return "com.android.chrome";
        if(n.contains("gmail"))return "com.google.android.gm"; if(n.contains("google maps"))return "com.google.android.apps.maps";
        if(n.contains("phonepe"))return "com.phonepe.app"; if(n.equals("paytm"))return "net.one97.paytm";
        return null;
    }
    private void openInstalledApp(String pkg){try{Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);if(launch!=null){startActivity(launch);return;}Toast.makeText(this,"App installed nahi hai. Play Store se install karein.",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"App open nahi ho paya",Toast.LENGTH_SHORT).show();}}
    private void openLink(String value){try{String url=value.trim();if(!url.startsWith("https://")&&!url.startsWith("http://"))url="https://"+url;startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(ActivityNotFoundException e){Toast.makeText(this,"Link open karne ke liye browser nahi mila",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Link open nahi ho paya",Toast.LENGTH_SHORT).show();}}
    private void updateFavorite(){boolean fav=FavoritesManager.getInstance().isFavorite(app.id);b.btnFavorite.setIconResource(fav?R.drawable.ic_heart_filled:R.drawable.ic_heart_outline);b.btnFavorite.setText(fav?"Remove favorite":"Add to favorites");}
}
