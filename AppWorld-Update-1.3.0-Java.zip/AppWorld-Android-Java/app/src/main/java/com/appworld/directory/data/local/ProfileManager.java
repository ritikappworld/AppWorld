package com.appworld.directory.data.local;

import android.content.Context;
import android.content.SharedPreferences;

/** Stores the personal profile locally on this device; no account or server upload is used. */
public final class ProfileManager {
    private static final String PREFS = "appworld_user_profile";
    private static ProfileManager instance;
    private final SharedPreferences prefs;
    private ProfileManager(Context context) { prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE); }
    public static synchronized void init(Context context) { if (instance == null) instance = new ProfileManager(context); }
    public static synchronized ProfileManager getInstance() { if (instance == null) throw new IllegalStateException("ProfileManager not initialized"); return instance; }
    public String getName() { return prefs.getString("name", "AppWorld User"); }
    public String getEmail() { return prefs.getString("email", ""); }
    public String getAbout() { return prefs.getString("about", "Discover useful apps and websites."); }
    public String getPhotoUri() { return prefs.getString("photo_uri", ""); }
    public void save(String name, String email, String about) { prefs.edit().putString("name", name == null ? "" : name.trim()).putString("email", email == null ? "" : email.trim()).putString("about", about == null ? "" : about.trim()).apply(); }
    public void savePhotoUri(String uri) { prefs.edit().putString("photo_uri", uri == null ? "" : uri).apply(); }
}
