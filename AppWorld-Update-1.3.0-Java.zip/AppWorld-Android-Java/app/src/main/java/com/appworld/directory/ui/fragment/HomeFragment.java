package com.appworld.directory.ui.fragment;
import android.os.Bundle;
import android.view.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.FragmentHomeBinding;
import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.List;
public class HomeFragment extends Fragment {
    private FragmentHomeBinding b; private AppCardAdapter adapter;
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        b = FragmentHomeBinding.inflate(inflater, container, false);
        adapter = new AppCardAdapter(FragmentTools.listener(this));
        b.recyclerApps.setLayoutManager(new LinearLayoutManager(requireContext())); b.recyclerApps.setAdapter(adapter);
        b.progressLoading.setVisibility(View.VISIBLE); b.textStatus.setText("Loading tools...");
        b.btnRetry.setOnClickListener(v -> load()); load(); return b.getRoot();
    }
    private void load() {
        if (b == null) return;
        b.progressLoading.setVisibility(View.VISIBLE); b.btnRetry.setVisibility(View.GONE);
        SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback() {
            @Override public void success(List<AppEntity> apps) { if (!isAdded() || b == null) return; b.progressLoading.setVisibility(View.GONE); adapter.setApps(apps); b.textStatus.setText(apps.isEmpty() ? "Abhi koi app available nahi hai." : apps.size() + " apps & websites available"); b.btnRetry.setVisibility(apps.isEmpty() ? View.VISIBLE : View.GONE); }
            @Override public void error(String message, List<AppEntity> fallback) { if (!isAdded() || b == null) return; b.progressLoading.setVisibility(View.GONE); adapter.setApps(fallback); b.textStatus.setText(fallback != null && !fallback.isEmpty() ? fallback.size() + " saved tools (offline)" : message); b.btnRetry.setVisibility(View.VISIBLE); }
        });
    }
    @Override public void onDestroyView() { super.onDestroyView(); b = null; }
}
