package com.appworld.directory.ui.fragment;
import android.os.Bundle; import android.view.*; import android.widget.Button; import android.widget.LinearLayout;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.recyclerview.widget.LinearLayoutManager;
import com.appworld.directory.data.model.AppEntity; import com.appworld.directory.data.supabase.SupabaseAppsRepository; import com.appworld.directory.databinding.FragmentCategoriesBinding; import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.*;
public class CategoriesFragment extends Fragment {
 private FragmentCategoriesBinding b; private AppCardAdapter adapter; private List<AppEntity> all=new ArrayList<>();
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){b=FragmentCategoriesBinding.inflate(i,c,false); adapter=new AppCardAdapter(FragmentTools.listener(this)); b.recyclerCategories.setLayoutManager(new LinearLayoutManager(requireContext())); b.recyclerCategories.setAdapter(adapter); all=SupabaseAppsRepository.getInstance().getCache(); buildCategories(); SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){public void success(List<AppEntity>a){if(isAdded()&&b!=null){all=a;buildCategories();showCategory("All");}} public void error(String m,List<AppEntity>a){if(isAdded()&&b!=null){all=a;buildCategories();showCategory("All");}}}); return b.getRoot();}
 private void buildCategories(){if(b==null)return;b.categoryButtons.removeAllViews();Set<String> names=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);for(AppEntity a:all)if(a!=null)names.add(a.getSafeCategory()); addButton("All");for(String n:names)addButton(n);}
 private void addButton(String name){Button button=new Button(requireContext());button.setText(name);button.setAllCaps(false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(0,0,8,0);b.categoryButtons.addView(button,lp);button.setOnClickListener(v->showCategory(name));}
 private void showCategory(String category){if(b==null)return;List<AppEntity> out=new ArrayList<>();for(AppEntity a:all)if(a!=null&&(category.equals("All")||a.getSafeCategory().equalsIgnoreCase(category)))out.add(a);adapter.setApps(out);b.textCategoryEmpty.setVisibility(out.isEmpty()?View.VISIBLE:View.GONE);b.textCategoryEmpty.setText("Is category mein abhi koi app nahi hai.");}
 @Override public void onDestroyView(){super.onDestroyView();b=null;}
}
