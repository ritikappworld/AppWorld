package com.appworld.directory.ui.adapter;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.appworld.directory.R;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.ui.LogoHelper;
import com.appworld.directory.databinding.ItemAppCardBinding;
import java.util.ArrayList;
import java.util.List;
public class AppCardAdapter extends RecyclerView.Adapter<AppCardAdapter.Holder> {
    public interface Listener { void click(AppEntity app); void favoriteChanged(AppEntity app, boolean favorite); }
    private final List<AppEntity> apps = new ArrayList<>();
    private final Listener listener;
    public AppCardAdapter(Listener listener) { this.listener = listener; }
    public void setApps(List<AppEntity> data) { apps.clear(); if (data != null) apps.addAll(data); notifyDataSetChanged(); }
    public List<AppEntity> getApps() { return new ArrayList<>(apps); }
    @NonNull @Override public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { return new Holder(ItemAppCardBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false)); }
    @Override public void onBindViewHolder(@NonNull Holder holder, int position) { holder.bind(apps.get(position)); }
    @Override public int getItemCount() { return apps.size(); }
    class Holder extends RecyclerView.ViewHolder {
        final ItemAppCardBinding b;
        Holder(ItemAppCardBinding binding) { super(binding.getRoot()); b = binding; }
        void bind(AppEntity app) {
            b.textName.setText(app.getSafeName()); b.textCategory.setText(app.getSafeCategory());
            b.textPricing.setText(app.pricing == null || app.pricing.trim().isEmpty() ? "Pricing not listed" : app.pricing);
            b.textRating.setText(app.rating > 0 ? String.format(java.util.Locale.getDefault(), "★ %.1f", app.rating) : "");
            String logo = LogoHelper.imageFor(app);
            com.bumptech.glide.RequestBuilder<android.graphics.drawable.Drawable> request = Glide.with(b.imageLogo).load(logo).placeholder(R.drawable.ic_app_placeholder);
            String fallback = LogoHelper.fallbackImageFor(app);
            if (fallback != null && (logo == null || !fallback.equals(logo))) request = request.error(Glide.with(b.imageLogo).load(fallback));
            else request = request.error(R.drawable.ic_app_placeholder);
            request.into(b.imageLogo);
            refreshHeart(app);
            b.btnHeart.setOnClickListener(v -> { boolean favorite = FavoritesManager.getInstance().toggleFavorite(app.id); refreshHeart(app); if (listener != null) listener.favoriteChanged(app, favorite); });
            itemView.setOnClickListener(v -> { if (listener != null) listener.click(app); });
        }
        void refreshHeart(AppEntity app) { b.btnHeart.setImageResource(FavoritesManager.getInstance().isFavorite(app.id) ? R.drawable.ic_heart_filled : R.drawable.ic_heart_outline); }
    }
}
