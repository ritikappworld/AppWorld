package com.appworld.directory.data.local;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/** Device-local profile, search history, recently viewed and collections. No sign-in required. */
public final class UserDataManager {
    private static final String PREF = "appworld_user_data";
    private static UserDataManager instance;
    private final SharedPreferences prefs;
    private UserDataManager(Context c) { prefs = c.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE); }
    public static synchronized UserDataManager get(Context c) { if (instance == null) instance = new UserDataManager(c); return instance; }
    public String getName() { return prefs.getString("profile_name", "AppWorld User"); }
    public void setName(String name) { prefs.edit().putString("profile_name", name == null ? "" : name.trim()).apply(); }
    public String getPhoto() { return prefs.getString("profile_photo", null); }
    public void setPhoto(String uri) { prefs.edit().putString("profile_photo", uri).apply(); }
    private List<String> getList(String key) { return new ArrayList<>(prefs.getStringSet(key, new LinkedHashSet<>())); }
    private void add(String key, String value, int limit) { if (value == null || value.trim().isEmpty()) return; LinkedHashSet<String> s = new LinkedHashSet<>(); s.add(value); s.addAll(getList(key)); while (s.size() > limit) s.remove(s.iterator().next()); prefs.edit().putStringSet(key, s).apply(); }
    public void addSearch(String q) { add("search_history", q, 15); }
    public List<String> getSearchHistory() { return getList("search_history"); }
    public void clearSearchHistory() { prefs.edit().remove("search_history").apply(); }
    public void addViewed(String id) { add("recently_viewed", id, 30); }
    public List<String> getRecentlyViewed() { return getList("recently_viewed"); }
    public void addCollection(String name) { add("collections", name, 30); }
    public List<String> getCollections() { return getList("collections"); }
}
