package com.appworld.directory.data.local;

import com.appworld.directory.data.model.AppEntity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** Curated offline starter catalogue. Supabase remains the primary live data source. */
public final class StarterApps {
    private StarterApps() {}

    public static List<AppEntity> create() {
        List<AppEntity> apps = new ArrayList<>();
        add(apps, "WhatsApp", "Messaging", "Messaging app for chats, voice and video calls.", "https://www.whatsapp.com/", "Free");
        add(apps, "Instagram", "Social", "Share photos, videos, stories and messages.", "https://www.instagram.com/", "Free");
        add(apps, "YouTube", "Video", "Watch, create and share videos.", "https://www.youtube.com/", "Free");
        add(apps, "Facebook", "Social", "Connect with friends, groups and communities.", "https://www.facebook.com/", "Free");
        add(apps, "Telegram", "Messaging", "Cloud-based messaging with channels and groups.", "https://telegram.org/", "Free");
        add(apps, "Gmail", "Productivity", "Email service by Google.", "https://mail.google.com/", "Free");
        add(apps, "Google Maps", "Travel", "Maps, navigation and local discovery.", "https://maps.google.com/", "Free");
        add(apps, "Google Drive", "Productivity", "Cloud storage and file sharing.", "https://drive.google.com/", "Freemium");
        add(apps, "Google Chrome", "Browser", "Fast web browser by Google.", "https://www.google.com/chrome/", "Free");
        add(apps, "Spotify", "Music", "Music and podcast streaming.", "https://www.spotify.com/", "Freemium");
        add(apps, "Netflix", "Entertainment", "Movies, series and entertainment streaming.", "https://www.netflix.com/", "Paid");
        add(apps, "Amazon", "Shopping", "Shop products and track orders.", "https://www.amazon.in/", "Free");
        add(apps, "Flipkart", "Shopping", "Online shopping across popular categories.", "https://www.flipkart.com/", "Free");
        add(apps, "Paytm", "Finance", "Digital payments and financial services.", "https://paytm.com/", "Free");
        add(apps, "PhonePe", "Finance", "UPI payments and recharge services.", "https://www.phonepe.com/", "Free");
        add(apps, "Google Pay", "Finance", "Make digital payments with Google Pay.", "https://pay.google.com/", "Free");
        add(apps, "ChatGPT", "AI Tools", "AI assistant for writing, learning and ideas.", "https://chatgpt.com/", "Freemium");
        add(apps, "Canva", "Design", "Create designs, presentations and social posts.", "https://www.canva.com/", "Freemium");
        add(apps, "Zoom", "Communication", "Video meetings and online collaboration.", "https://zoom.us/", "Freemium");
        add(apps, "Google Meet", "Communication", "Video meetings from Google.", "https://meet.google.com/", "Free");
        add(apps, "Microsoft Word", "Productivity", "Create and edit documents.", "https://www.microsoft.com/microsoft-365/word", "Freemium");
        add(apps, "Google Docs", "Productivity", "Create and collaborate on documents.", "https://docs.google.com/", "Free");
        add(apps, "Notion", "Productivity", "Workspace for notes, tasks and projects.", "https://www.notion.so/", "Freemium");
        add(apps, "GitHub", "Developer Tools", "Host code and collaborate on software.", "https://github.com/", "Free");
        add(apps, "Duolingo", "Education", "Learn languages with short lessons.", "https://www.duolingo.com/", "Freemium");
        add(apps, "Khan Academy", "Education", "Free learning resources and lessons.", "https://www.khanacademy.org/", "Free");
        add(apps, "Pinterest", "Lifestyle", "Discover and save ideas and inspiration.", "https://www.pinterest.com/", "Free");
        add(apps, "X", "Social", "Follow conversations and current topics.", "https://x.com/", "Free");
        return apps;
    }

    private static void add(List<AppEntity> list, String name, String category, String description, String website, String pricing) {
        AppEntity app = new AppEntity();
        app.id = "starter-" + name.toLowerCase(java.util.Locale.ROOT).replaceAll("[^a-z0-9]+", "-");
        app.name = name;
        app.category = category;
        app.description = description;
        app.officialWebsite = website;
        app.pricing = pricing;
        app.type = "app";
        app.platforms = new ArrayList<>(Arrays.asList("Android", "Web"));
        app.features = new ArrayList<>();
        list.add(app);
    }
}
