package com.appworld.directory.data.local;
import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;
public class FavoritesManager {
    private static FavoritesManager instance;
    private final SharedPreferences prefs;
    private FavoritesManager(Context c) { prefs = c.getApplicationContext().getSharedPreferences("appworld_favorites", Context.MODE_PRIVATE); }
    public static synchronized void init(Context c) { if (instance == null) instance = new FavoritesManager(c); }
    public static synchronized FavoritesManager getInstance() { if (instance == null) throw new IllegalStateException("FavoritesManager not initialized"); return instance; }
    public synchronized boolean isFavorite(String id) { return id != null && getFavoriteIds().contains(id); }
    public synchronized boolean toggleFavorite(String id) {
        if (id == null || id.trim().isEmpty()) return false;
        Set<String> ids = getFavoriteIds(); boolean added = !ids.contains(id);
        if (added) ids.add(id); else ids.remove(id);
        prefs.edit().putStringSet("ids", ids).apply(); return added;
    }
    public synchronized Set<String> getFavoriteIds() { return new HashSet<>(prefs.getStringSet("ids", new HashSet<>())); }
}
