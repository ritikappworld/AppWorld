APPWORLD ANDROID JAVA - BUILD NOTES

This project is Java (not Kotlin), min Android API 21, compile/target SDK 34.

FEATURES INCLUDED
- Supabase public.apps REST loading with loading/error/retry states
- Local JSON cache for offline display
- App logo loading with Glide placeholders
- Live search across name, category, description, type and pricing
- Dynamic categories from the Supabase data
- Favorites saved locally on the device
- App detail screen and official website / store link opening
- Working Home, Categories, Search, Favorites and Profile bottom navigation

IMPORTANT SUPABASE SETUP
1. Open gradle.properties in the project root.
2. Replace SUPABASE_URL with your Supabase Project URL (example: https://xxxx.supabase.co).
3. Replace SUPABASE_ANON_KEY with the project's anon / publishable client key.
4. Do NOT use the service_role key or any secret key in an Android app.
5. Supabase must have a public table named public.apps, and SELECT access must be allowed by its Row Level Security policy for the anon role.
6. The app expects columns such as: id, name, logo, description, category, type, pricing, rating, platforms, official_website, google_play_url, app_store_url, features, screenshots, verified, date_added. Missing optional columns are okay because it requests select=*; the fields it doesn't receive stay empty.

BUILD ENVIRONMENT
- Android Gradle Plugin 8.8.2
- Use Gradle 8.10.2 or compatible wrapper
- Use JDK 17 for the Android Gradle build
- Android SDK Platform 34 and Build Tools installed

The source ZIP is not an APK. A successful cloud/device build and runtime test still need to be done with your own Supabase URL/key and database permissions. No source project can guarantee that an external Supabase project is configured correctly.

AppWorld 1.1 UI update
- White/light theme with blue accents.
- Added the supplied AppWorld brand logo as the app launcher icon and Profile header.
- Missing/broken app-logo URLs now fall back to the AppWorld brand mark (actual third-party logos still need valid logo URLs in Supabase public.apps.logo).
- Expanded Profile with My Profile, Total Apps & Websites, My Favorites, Refresh App List, Settings, About, Privacy, Contact, Rate and App Version entries.
- Existing Home, Search, Categories, Favorites and detail screens were retained; colors are switched centrally to the light palette.
- My Profile is informational only because this build has no sign-in/account backend.
