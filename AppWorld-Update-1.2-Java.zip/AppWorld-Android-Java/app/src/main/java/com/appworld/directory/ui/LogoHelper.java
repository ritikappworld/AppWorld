package com.appworld.directory.ui;

import android.net.Uri;
import com.appworld.directory.data.model.AppEntity;

/** Returns the supplied logo first, then a domain favicon as a lightweight brand fallback. */
public final class LogoHelper {
    private LogoHelper() {}
    public static String imageFor(AppEntity app) {
        if (app == null) return null;
        if (app.logo != null && !app.logo.trim().isEmpty()) return app.logo.trim();
        String site = app.officialWebsite;
        if (site == null || site.trim().isEmpty()) {
            String n = app.getSafeName().toLowerCase(java.util.Locale.ROOT);
            if (n.contains("whatsapp")) site = "https://www.whatsapp.com";
            else if (n.contains("instagram")) site = "https://www.instagram.com";
            else if (n.contains("youtube")) site = "https://www.youtube.com";
            else if (n.contains("facebook")) site = "https://www.facebook.com";
            else if (n.contains("telegram")) site = "https://telegram.org";
            else if (n.contains("chatgpt")) site = "https://chatgpt.com";
        }
        if (site == null || site.trim().isEmpty()) return null;
        try {
            Uri uri = Uri.parse(site.trim().startsWith("http") ? site.trim() : "https://" + site.trim());
            String host = uri.getHost();
            return host == null ? null : "https://www.google.com/s2/favicons?domain=" + host + "&sz=128";
        } catch (Exception ignored) { return null; }
    }
}
