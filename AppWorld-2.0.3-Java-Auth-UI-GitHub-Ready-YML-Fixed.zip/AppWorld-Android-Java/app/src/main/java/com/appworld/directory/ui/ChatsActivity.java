package com.appworld.directory.ui;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.appworld.directory.databinding.ActivityChatsBinding;

/** Separate Chats UI. Live messaging is intentionally gated until Supabase Auth/client integration is completed. */
public class ChatsActivity extends AppCompatActivity {
    private ActivityChatsBinding binding;
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        binding = ActivityChatsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btnChatsBack.setOnClickListener(v -> finish());
        binding.btnNewChat.setOnClickListener(v -> binding.textChatsStatus.setText("Secure account sign-in and Supabase messaging setup are required before creating a conversation."));
    }
}
