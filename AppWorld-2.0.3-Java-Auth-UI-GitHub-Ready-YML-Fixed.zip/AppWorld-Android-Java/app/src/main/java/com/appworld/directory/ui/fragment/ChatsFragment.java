package com.appworld.directory.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.appworld.directory.databinding.ActivityChatsBinding;

/** Chats tab entry. No fake conversations are rendered. */
public class ChatsFragment extends Fragment {
    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        ActivityChatsBinding b=ActivityChatsBinding.inflate(inflater,container,false);
        b.btnChatsBack.setVisibility(View.GONE);
        b.btnNewChat.setOnClickListener(v->startActivity(new android.content.Intent(requireContext(),com.appworld.directory.ui.AccountActivity.class)));
        b.btnChatsSignin.setEnabled(true);
        b.btnChatsSignin.setText("Sign In / Create Account");
        b.btnChatsSignin.setOnClickListener(v->startActivity(new android.content.Intent(requireContext(),com.appworld.directory.ui.AccountActivity.class)));
        b.textChatsStatus.setText("Sign in to AppWorld to start personal chats, group conversations and message requests. Live messaging will be enabled after the Realtime client integration. No sample or fake chats are shown.");
        return b.getRoot();
    }
}
