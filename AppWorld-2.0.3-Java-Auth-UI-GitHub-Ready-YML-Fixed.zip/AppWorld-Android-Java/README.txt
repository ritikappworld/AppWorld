APPWORLD ANDROID JAVA - 2.0.3 BUILD NOTES

Platform: Native Android Java (not Kotlin), min API 21, compile/target SDK 34.
Application ID: com.appworld.directory
Version: 2.0.3 (versionCode 6)
Android Gradle Plugin: 8.8.2; Gradle: 8.10.2; JDK: 17; Java source compatibility: 8.

PRESERVED DIRECTORY FEATURES
- Supabase public.apps REST loading with loading/error/retry states and local JSON cache.
- App logos, app details, official website / store / installed-app opening.
- Search, quick search, dynamic categories, filters and local search history.
- Local favorites, profile name/photo, recently viewed and collections.
- Home, Categories, Search, Favorites, Profile, Settings, Profile Library, Reels and Chats entry screens.

NEW IN 2.0.3
- Supabase email/password Sign In and Sign Up screen accessible from Profile.
- Sign Out and account session status.
- Auth uses the existing project URL and anon/publishable key configuration.
- Bottom navigation matches the reference tabs: Home, Categories, Reels, Chats and Profile. Search and Favorites remain reachable from Home/Profile.
- SQL foundation for profile records and automatic profile creation on Auth signup.

SUPABASE CONFIGURATION
1. Enable Authentication > Providers > Email in the Supabase Dashboard.
2. Run APPWORLD-2.0.3-AUTH-FOUNDATION.sql in the Supabase SQL Editor.
3. Configure SUPABASE_URL and SUPABASE_ANON_KEY in gradle.properties, or add GitHub repository secrets with those exact names.
4. Never use the service_role key or any secret key in an Android app.
5. For the app directory, public.apps still needs SELECT access for anon under its RLS policy.
6. Email confirmation behavior depends on Supabase Auth settings. If enabled, confirm the signup email before sign-in.

BUILD
- GitHub Actions workflow: .github/workflows/build-apk.yml
- Expected artifact: AppWorld-2.0.3-debug-apk
- Source ZIP is not an APK. Use the workflow to build and obtain the APK.

IMPORTANT STATUS
- Reels and Chats are still entry screens; live video feed/upload, messaging/realtime, follow, comments and push notifications are not claimed as completed.
- Automatic refresh-token rotation and encrypted session-token storage are not implemented in 2.0.3.
- The Android SDK/Gradle build cannot be verified in this working environment. A green GitHub Actions run and an install/runtime test are still required.
