
package com.appworld.directory.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.FragmentHomeBinding;
import com.appworld.directory.ui.MainActivity;
import com.appworld.directory.ui.adapter.AppCardAdapter;

import java.util.List;

public class HomeFragment extends Fragment {

    private FragmentHomeBinding b;
    private AppCardAdapter a;

    @Override
    public View onCreateView(LayoutInflater i, ViewGroup c, Bundle s) {

        b = FragmentHomeBinding.inflate(i, c, false);

        a = new AppCardAdapter(
                x -> ((MainActivity) requireActivity()).openTool(x)
        );

        b.recyclerApps.setAdapter(a);

        load();

        return b.getRoot();
    }

    private void load() {

        SupabaseAppsRepository.getInstance().fetchApps(
                new SupabaseAppsRepository.Callback() {

                    @Override
                    public void success(List<AppEntity> apps) {

                        a.setApps(apps);

                        if (apps == null || apps.isEmpty()) {
                            b.textStatus.setText("No tools available");
                        } else {
                            b.textStatus.setText(
                                    apps.size() + " tools available"
                            );
                        }
                    }

                    @Override
                    public void error(
                            String errorMessage,
                            List<AppEntity> fallbackApps
                    ) {

                        if (fallbackApps != null && !fallbackApps.isEmpty()) {
                            a.setApps(fallbackApps);
                            b.textStatus.setText(
                                    fallbackApps.size() + " cached tools"
                            );
                        } else {
                            b.textStatus.setText(
                                    "Error: " + errorMessage
                            );
                        }
                    }
                }
        );
    }
}


























