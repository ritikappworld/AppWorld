package com.appworld.directory.ui.fragment;
import android.os.Bundle; import android.text.Editable; import android.text.TextWatcher; import android.view.*;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.recyclerview.widget.LinearLayoutManager;
import com.appworld.directory.data.model.AppEntity; import com.appworld.directory.data.supabase.SupabaseAppsRepository; import com.appworld.directory.databinding.FragmentSearchBinding; import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.*;
public class SearchFragment extends Fragment {
 private FragmentSearchBinding b; private AppCardAdapter adapter; private List<AppEntity> all = new ArrayList<>();
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ b=FragmentSearchBinding.inflate(i,c,false); adapter=new AppCardAdapter(FragmentTools.listener(this)); b.recyclerSearch.setLayoutManager(new LinearLayoutManager(requireContext())); b.recyclerSearch.setAdapter(adapter);
 b.editSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int st,int count,int after){} public void onTextChanged(CharSequence x,int st,int before,int count){filter(x.toString());} public void afterTextChanged(Editable e){}});
 all=SupabaseAppsRepository.getInstance().getCache(); filter(""); SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){public void success(List<AppEntity> a){if(isAdded()&&b!=null){all=a;filter(b.editSearch.getText().toString());}} public void error(String m,List<AppEntity> a){if(isAdded()&&b!=null){all=a;filter(b.editSearch.getText().toString());}}}); return b.getRoot(); }
 private void filter(String q){if(b==null)return; String needle=q==null?"":q.trim().toLowerCase(Locale.ROOT); List<AppEntity> out=new ArrayList<>(); for(AppEntity a:all){if(a==null)continue; String hay=(a.name+" "+a.category+" "+a.description+" "+a.type+" "+a.pricing+" "+a.officialWebsite+" "+join(a.platforms)+" "+join(a.features)).toLowerCase(Locale.ROOT); if(needle.isEmpty()||hay.contains(needle))out.add(a);} adapter.setApps(out); b.textSearchEmpty.setVisibility(out.isEmpty()?View.VISIBLE:View.GONE); b.textSearchEmpty.setText(needle.isEmpty()?"No apps available yet.":"No matching apps found."); }
 private String join(List<String> values){return values==null?"":android.text.TextUtils.join(" ",values);}
 @Override public void onDestroyView(){super.onDestroyView();b=null;}
}
