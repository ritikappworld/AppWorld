package com.appworld.directory.ui.fragment;

import android.os.Bundle; import android.text.Editable; import android.text.TextWatcher; import android.view.*; import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.recyclerview.widget.LinearLayoutManager;
import com.appworld.directory.data.model.AppEntity; import com.appworld.directory.data.supabase.SupabaseAppsRepository; import com.appworld.directory.databinding.FragmentSearchBinding; import com.appworld.directory.ui.MainActivity; import com.appworld.directory.ui.adapter.AppCardAdapter; import java.util.*;
public class SearchFragment extends Fragment {
 private FragmentSearchBinding b; private AppCardAdapter adapter; private List<AppEntity> all=new ArrayList<>();
 @Nullable public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ b=FragmentSearchBinding.inflate(i,c,false); b.recyclerSearch.setLayoutManager(new LinearLayoutManager(requireContext())); adapter=new AppCardAdapter(a->((MainActivity)requireActivity()).openTool(a)); b.recyclerSearch.setAdapter(adapter); b.editSearch.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int st,int count,int after){} public void onTextChanged(CharSequence x,int st,int before,int count){filter(x.toString());} public void afterTextChanged(Editable e){}}); load(); return b.getRoot(); }
 private void load(){ SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){public void success(List<AppEntity>x){if(!isAdded()||b==null)return; all=x;filter(b.editSearch.getText().toString());} public void error(String m,List<AppEntity>x){if(!isAdded()||b==null)return;all=x;filter(b.editSearch.getText().toString());}}); }
 private void filter(String q){String n=q.toLowerCase(Locale.ROOT).trim();List<AppEntity> out=new ArrayList<>();for(AppEntity a:all){String hay=((a.name==null?"":a.name)+" "+(a.category==null?"":a.category)+" "+(a.description==null?"":a.description)).toLowerCase(Locale.ROOT);if(hay.contains(n))out.add(a);}adapter.setApps(out);}
 @Override public void onDestroyView(){super.onDestroyView();b=null;}
}
