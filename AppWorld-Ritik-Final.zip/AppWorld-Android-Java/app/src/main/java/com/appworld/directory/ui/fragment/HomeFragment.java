package com.appworld.directory.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.FragmentHomeBinding;
import com.appworld.directory.ui.MainActivity;
import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.List;

public class HomeFragment extends Fragment {
    private FragmentHomeBinding binding;
    private AppCardAdapter adapter;

    @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentHomeBinding.inflate(inflater, container, false);
        binding.recyclerApps.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new AppCardAdapter(app -> ((MainActivity) requireActivity()).openTool(app));
        binding.recyclerApps.setAdapter(adapter);
        binding.textStatus.setText("Loading tools...");
        loadApps();
        return binding.getRoot();
    }

    private void loadApps() {
        SupabaseAppsRepository repo = SupabaseAppsRepository.getInstance();
        if (repo == null) { binding.textStatus.setText("App is not initialized. Please restart."); return; }
        repo.fetchApps(new SupabaseAppsRepository.Callback() {
            @Override public void success(List<AppEntity> apps) {
                if (!isAdded() || binding == null) return;
                adapter.setApps(apps);
                binding.textStatus.setText(apps.isEmpty() ? "No tools found. Add records to Supabase public.apps." : apps.size() + " tools available");
            }
            @Override public void error(String message, List<AppEntity> fallback) {
                if (!isAdded() || binding == null) return;
                if (fallback != null && !fallback.isEmpty()) {
                    adapter.setApps(fallback);
                    binding.textStatus.setText(fallback.size() + " saved tools (offline)");
                } else binding.textStatus.setText("Could not load tools: " + message);
            }
        });
    }
    @Override public void onDestroyView() { super.onDestroyView(); binding = null; }
}
