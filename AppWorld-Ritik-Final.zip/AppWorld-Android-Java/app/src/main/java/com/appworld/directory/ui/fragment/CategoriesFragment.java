package com.appworld.directory.ui.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.android.material.chip.Chip;
import com.appworld.directory.data.model.AppEntity;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.FragmentCategoriesBinding;
import com.appworld.directory.ui.MainActivity;
import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.TreeSet;

public class CategoriesFragment extends Fragment {
    private FragmentCategoriesBinding binding;
    private AppCardAdapter adapter;
    private List<AppEntity> allApps = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        binding = FragmentCategoriesBinding.inflate(inflater, container, false);
        binding.recyclerCategories.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new AppCardAdapter(app -> ((MainActivity) requireActivity()).openTool(app));
        binding.recyclerCategories.setAdapter(adapter);
        loadApps();
        return binding.getRoot();
    }

    private void loadApps() {
        SupabaseAppsRepository repository = SupabaseAppsRepository.getInstance();
        if (repository == null) {
            binding.textCategoriesStatus.setText("App is not initialized. Please restart.");
            return;
        }
        repository.fetchApps(new SupabaseAppsRepository.Callback() {
            @Override public void success(List<AppEntity> apps) { showCategories(apps); }
            @Override public void error(String message, List<AppEntity> fallback) {
                showCategories(fallback);
                if (isAdded() && binding != null && (fallback == null || fallback.isEmpty())) {
                    binding.textCategoriesStatus.setText("Could not load categories: " + message);
                }
            }
        });
    }

    private void showCategories(List<AppEntity> apps) {
        if (!isAdded() || binding == null) return;
        allApps = apps == null ? new ArrayList<>() : new ArrayList<>(apps);
        binding.chipGroupCategories.removeAllViews();
        TreeSet<String> categories = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (AppEntity app : allApps) {
            if (app.category != null && !app.category.trim().isEmpty()) categories.add(app.category.trim());
        }
        if (categories.isEmpty()) {
            binding.textCategoriesStatus.setText("No categories found. Add category values to public.apps.");
            adapter.setApps(allApps);
            return;
        }
        binding.textCategoriesStatus.setText(categories.size() + " categories available");
        addCategoryChip("All", true);
        for (String category : categories) addCategoryChip(category, false);
        adapter.setApps(allApps);
    }

    private void addCategoryChip(String label, boolean checked) {
        Chip chip = new Chip(requireContext());
        chip.setText(label);
        chip.setCheckable(true);
        chip.setClickable(true);
        chip.setChecked(checked);
        chip.setOnClickListener(v -> filterByCategory(label));
        binding.chipGroupCategories.addView(chip);
    }

    private void filterByCategory(String category) {
        if ("All".equalsIgnoreCase(category)) {
            adapter.setApps(allApps);
            return;
        }
        List<AppEntity> filtered = new ArrayList<>();
        for (AppEntity app : allApps) {
            if (app.category != null && app.category.trim().toLowerCase(Locale.ROOT)
                    .equals(category.toLowerCase(Locale.ROOT))) filtered.add(app);
        }
        adapter.setApps(filtered);
    }

    @Override public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
