package com.appworld.directory.data.supabase;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import com.appworld.directory.data.model.AppEntity;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import okhttp3.Call;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class SupabaseAppsRepository {
    private static volatile SupabaseAppsRepository instance;
    private final String baseUrl, key;
    private final OkHttpClient client = new OkHttpClient();
    private final Gson gson = new Gson();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile List<AppEntity> cache = new ArrayList<>();

    public interface Callback { void success(List<AppEntity> apps); void error(String message, List<AppEntity> fallback); }
    private SupabaseAppsRepository(Context context, String url, String anonKey) {
        baseUrl = url == null ? "" : url.trim().replaceAll("/+$", "");
        key = anonKey == null ? "" : anonKey.trim();
    }
    public static synchronized void init(Context context, String url, String key) {
        if (instance == null) instance = new SupabaseAppsRepository(context.getApplicationContext(), url, key);
    }
    public static SupabaseAppsRepository getInstance() { return instance; }

    public void fetchApps(Callback callback) {
        if (callback == null) return;
        if (baseUrl.isEmpty() || baseUrl.contains("your-project-ref") || key.isEmpty() || key.startsWith("YOUR_")) {
            main.post(() -> callback.error("Supabase settings are missing. Add SUPABASE_URL and SUPABASE_ANON_KEY to GitHub Actions secrets/build properties.", getCache()));
            return;
        }
        Request request;
        try {
            request = new Request.Builder().url(baseUrl + "/rest/v1/apps?select=*&order=rating.desc")
                    .header("apikey", key).header("Authorization", "Bearer " + key)
                    .header("Accept", "application/json").get().build();
        } catch (IllegalArgumentException e) {
            main.post(() -> callback.error("Invalid Supabase URL.", getCache())); return;
        }
        client.newCall(request).enqueue(new okhttp3.Callback() {
            @Override public void onFailure(Call call, IOException e) {
                String msg = e.getLocalizedMessage() == null ? "Network connection failed" : e.getLocalizedMessage();
                main.post(() -> callback.error(msg, getCache()));
            }
            @Override public void onResponse(Call call, Response response) {
                try (Response res = response; ResponseBody body = res.body()) {
                    if (!res.isSuccessful()) {
                        String details = body == null ? "" : body.string();
                        String message = "Supabase HTTP " + res.code() + (details.isEmpty() ? "" : ": " + details);
                        main.post(() -> callback.error(message, getCache())); return;
                    }
                    if (body == null) { main.post(() -> callback.error("Supabase returned an empty response.", getCache())); return; }
                    Type type = new TypeToken<List<AppEntity>>() {}.getType();
                    List<AppEntity> result = gson.fromJson(body.string(), type);
                    List<AppEntity> safe = result == null ? new ArrayList<>() : new ArrayList<>(result);
                    cache = Collections.unmodifiableList(safe);
                    main.post(() -> callback.success(getCache()));
                } catch (IOException | JsonSyntaxException e) {
                    String message = e.getLocalizedMessage() == null ? "Could not read Supabase response" : e.getLocalizedMessage();
                    main.post(() -> callback.error(message, getCache()));
                }
            }
        });
    }
    public List<AppEntity> getCache() { return new ArrayList<>(cache); }
}
