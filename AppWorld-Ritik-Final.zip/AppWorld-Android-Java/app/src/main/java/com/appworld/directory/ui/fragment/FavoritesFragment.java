package com.appworld.directory.ui.fragment;
import android.os.Bundle; import android.view.*; import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.recyclerview.widget.LinearLayoutManager;
import com.appworld.directory.data.local.FavoritesManager; import com.appworld.directory.data.model.AppEntity; import com.appworld.directory.data.supabase.SupabaseAppsRepository; import com.appworld.directory.databinding.FragmentFavoritesBinding; import com.appworld.directory.ui.adapter.AppCardAdapter;
import java.util.*;
public class FavoritesFragment extends Fragment {
 private FragmentFavoritesBinding b; private AppCardAdapter adapter;
 @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){b=FragmentFavoritesBinding.inflate(i,c,false);adapter=new AppCardAdapter(new AppCardAdapter.Listener(){public void click(AppEntity a){FragmentTools.open(FavoritesFragment.this,a);}public void favoriteChanged(AppEntity a,boolean f){showFavorites();}});b.recyclerFavorites.setLayoutManager(new LinearLayoutManager(requireContext()));b.recyclerFavorites.setAdapter(adapter);showFavorites();SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback(){public void success(List<AppEntity>a){if(isAdded()&&b!=null)showFavorites();}public void error(String m,List<AppEntity>a){if(isAdded()&&b!=null)showFavorites();}});return b.getRoot();}
 private void showFavorites(){if(b==null)return;Set<String> ids=FavoritesManager.getInstance().getFavoriteIds();List<AppEntity> out=new ArrayList<>();for(AppEntity a:SupabaseAppsRepository.getInstance().getCache())if(a!=null&&ids.contains(a.getStableId()))out.add(a);adapter.setApps(out);b.textFavoritesEmpty.setVisibility(out.isEmpty()?View.VISIBLE:View.GONE);}
 @Override public void onResume(){super.onResume();if(b!=null)showFavorites();}
 @Override public void onDestroyView(){super.onDestroyView();b=null;}
}
