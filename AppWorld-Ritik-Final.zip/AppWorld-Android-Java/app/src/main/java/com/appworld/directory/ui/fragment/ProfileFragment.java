package com.appworld.directory.ui.fragment;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.appworld.directory.data.local.FavoritesManager;
import com.appworld.directory.data.supabase.SupabaseAppsRepository;
import com.appworld.directory.databinding.FragmentProfileBinding;
import com.appworld.directory.ui.MainActivity;

public class ProfileFragment extends Fragment {
    private FragmentProfileBinding b;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle state) {
        b = FragmentProfileBinding.inflate(inflater, container, false);
        update();
        b.btnRefreshProfile.setOnClickListener(v -> refreshApps());
        b.btnMyProfile.setOnClickListener(v -> new AlertDialog.Builder(requireContext())
                .setTitle("My Profile")
                .setMessage("AppWorld is currently available without sign-in. A personal account feature can be added in a future update.")
                .setPositiveButton("OK", null).show());
        b.btnMyFavorites.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).selectFavorites();
        });
        b.btnSettings.setOnClickListener(v -> new AlertDialog.Builder(requireContext())
                .setTitle("Settings")
                .setItems(new String[]{"Refresh app list", "App information"}, (dialog, which) -> {
                    if (which == 0) refreshApps();
                    else showAbout();
                }).show());
        b.btnAbout.setOnClickListener(v -> showAbout());
        b.btnPrivacy.setOnClickListener(v -> new AlertDialog.Builder(requireContext())
                .setTitle("Privacy Policy")
                .setMessage("AppWorld displays app and website information retrieved from its directory. Favorites are stored locally on this device. This version does not provide user sign-in.")
                .setPositiveButton("OK", null).show());
        b.btnContact.setOnClickListener(v -> {
            Intent email = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"));
            email.putExtra(Intent.EXTRA_SUBJECT, "AppWorld Support");
            try { startActivity(Intent.createChooser(email, "Contact AppWorld")); }
            catch (ActivityNotFoundException e) { Toast.makeText(requireContext(), "No email app found", Toast.LENGTH_SHORT).show(); }
        });
        b.btnRate.setOnClickListener(v -> {
            Uri market = Uri.parse("market://details?id=" + requireContext().getPackageName());
            try { startActivity(new Intent(Intent.ACTION_VIEW, market)); }
            catch (ActivityNotFoundException e) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=" + requireContext().getPackageName())));
            }
        });
        try {
            String version = requireContext().getPackageManager().getPackageInfo(requireContext().getPackageName(), 0).versionName;
            b.textAppVersion.setText("App Version " + version);
        } catch (Exception ignored) { b.textAppVersion.setText("App Version"); }
        return b.getRoot();
    }

    private void showAbout() {
        new AlertDialog.Builder(requireContext()).setTitle("About AppWorld")
                .setMessage("AppWorld is an apps and websites directory that helps you discover useful digital tools in one place.")
                .setPositiveButton("OK", null).show();
    }

    private void refreshApps() {
        if (b == null) return;
        b.textProfileStatus.setText("Refreshing app list…");
        SupabaseAppsRepository.getInstance().fetchApps(new SupabaseAppsRepository.Callback() {
            @Override public void success(java.util.List<com.appworld.directory.data.model.AppEntity> apps) {
                if (isAdded() && b != null) {
                    update();
                    b.textProfileStatus.setText("App list updated");
                }
            }
            @Override public void error(String message, java.util.List<com.appworld.directory.data.model.AppEntity> apps) {
                if (isAdded() && b != null) {
                    update();
                    b.textProfileStatus.setText(message == null ? "Could not refresh. Showing saved apps." : message);
                }
            }
        });
    }

    private void update() {
        if (b == null) return;
        b.textProfileApps.setText("Total apps & websites: " + SupabaseAppsRepository.getInstance().getCache().size());
        b.textProfileFavorites.setText("My favorites: " + FavoritesManager.getInstance().getFavoriteIds().size());
    }

    @Override public void onResume() { super.onResume(); if (b != null) update(); }
    @Override public void onDestroyView() { super.onDestroyView(); b = null; }
}
