APPWORLD ANDROID JAVA — FINAL SOURCE PACKAGE (v1.2)

PROJECT
- Native Android app written in Java (not Kotlin)
- Application ID: com.appworld.directory
- minSdk 21, compileSdk 34, targetSdk 34
- Android Gradle Plugin 8.8.2; Gradle 8.10.2; JDK 17

INCLUDED
- White/light AppWorld theme and supplied brand logo
- Home list loaded from Supabase public.apps
- Cached app list for offline fallback
- Glide logo loading with local placeholder
- Search across name, category, description, type, pricing, website, platforms and features
- Dynamic categories
- Device-local favorites (uses database id, or app name as fallback)
- App detail page and website/store links
- Installed-app launch when package_name is supplied (including WhatsApp)
- Home, Categories, Search, Favorites and Profile navigation
- Profile actions: refresh, favorites, settings/about/privacy/contact/rate

IMPORTANT LIMITATIONS — PLEASE READ
1. This source package cannot contain your private Supabase project settings. Configure GitHub repository Actions secrets named SUPABASE_URL and SUPABASE_ANON_KEY. Use only the Supabase anon/publishable client key, never service_role or secret keys.
2. Supabase must contain public.apps and permit SELECT for the anon role through its RLS policy. The app requests select=* and sorts by rating, so the table should include the columns listed below.
3. For real app logos, put the actual official logo image URL in the logo column (logo_url and icon_url are also accepted). A placeholder is shown if a URL is absent or broken. This package does not scrape or bundle every company's logo.
4. For direct installed-app opening, populate package_name, e.g. com.whatsapp. If the app is not installed, the app falls back to its website/store URL when one is supplied.
5. My Profile is informational; there is no login, cloud profile, or account system in this version.
6. Trending / Popular / Recently Added are not separate curated home sections in this package. They require reliable ranking/date data and a designed home feed; do not treat them as implemented.
7. A successful GitHub build proves compilation only. Runtime data, logos, links and RLS must still be tested against your own Supabase project on a phone.

EXPECTED / SUPPORTED DATABASE FIELDS
id, name, logo (or logo_url / icon_url), description, category, type, pricing,
rating, platforms, official_website (or website_url / url), package_name,
google_play_url, app_store_url, features, screenshots, verified, date_added,
created_at.

GITHUB BUILD
- Put this source archive in the repository root with the exact name AppWorld-Ritik-Final.zip.
- Put .github/workflows/build-appworld.yml in the repository.
- Add Actions secrets SUPABASE_URL and SUPABASE_ANON_KEY.
- Open GitHub Actions > Build AppWorld APK > Run workflow.
- Download the AppWorld-debug-apk artifact after a green build.

SECURITY
The Android client necessarily contains a public anon/publishable key. Protect data with Supabase Row Level Security. Never put service_role keys, database passwords, or other secrets in the Android app or GitHub source archive.
