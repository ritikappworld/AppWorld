APPWORLD ANDROID (JAVA) - UPDATED PROJECT

Open this folder as an Android Gradle project. Package: com.appworld.directory.
Java source is used (not Kotlin). minSdk 21, compileSdk 35, AGP 8.8.2.

SUPABASE CONFIGURATION (required for live data)
Set Gradle project properties before building:
SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
SUPABASE_ANON_KEY=YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY
For GitHub Actions, store these as repository Actions secrets and pass them to Gradle as -PSUPABASE_URL="$SUPABASE_URL" -PSUPABASE_ANON_KEY="$SUPABASE_ANON_KEY".
Do not put a service_role key in the Android app. Use only the anon/publishable key and configure Row Level Security policies for public read access to public.apps.

EXPECTED SUPABASE TABLE
public.apps should contain fields compatible with AppEntity: id, name, logo, description, category, type, pricing, rating, platforms, official_website, google_play_url, app_store_url, features, screenshots, verified, date_added, created_at.
The REST endpoint used is /rest/v1/apps?select=*&order=rating.desc.

WHAT WAS REPAIRED
- Fixed Gradle BuildConfig string quoting and removed fake credentials from gradle.properties.
- Added missing RecyclerView layout manager (previously lists could remain invisible).
- Improved Supabase URL/credential checks, HTTP error reporting, JSON error handling and cache safety.
- Added working search and favorites list screens, and connected category screen to the apps feed.
- Added lifecycle guards to asynchronous fragment callbacks.

IMPORTANT
This source has been statically reviewed, but a successful Android build and runtime test still depend on your actual Supabase credentials, table schema, RLS policy, Android SDK and build environment. No one can honestly guarantee zero errors without building and testing with those exact settings.
